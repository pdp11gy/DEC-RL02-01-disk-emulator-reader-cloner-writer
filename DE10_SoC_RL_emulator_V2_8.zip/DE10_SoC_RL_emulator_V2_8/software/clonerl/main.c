﻿/*
              *****************************************************************************
              *  Copyright (C) by Reinhard Heuberger  , www.pdp11gy.com                   *
              *                                                                           *
              *  All rights reserved.                                                     *
              *                                                                           *
              *  Redistribution and use in source and binary forms, with or without       *
              *  modification, are permitted provided that the following conditions       *
              *  are met:                                                                 *
              *                                                                           *
              *  1. Redistributions of source code must retain the above copyright        *
              *     notice, this list of conditions and the following disclaimer.         *
              *  2. Redistributions in binary form must reproduce the above copyright     *
              *     notice, this list of conditions and the following disclaimer in the   *
              *     documentation and/or other materials provided with the distribution.  *
              *  3. Neither the name of the author nor the names of its contributors may  *
              *     be used to endorse or promote products derived from this software     *
              *     without specific prior written permission.                            *
              *                                                                           *
              *****************************************************************************
                          RL01/RL02 cloner/reader for SoC HPS FPGA-environment
                                           Version V2.8E  

                     by: Reinhard Heuberger , www.PDP11GY.com, info@pdp11gy.com


                                 Data - Structure and Mapping:

                         |<--------- onboard RAM --------->|      |<- DP-RAM-->|

              / 5.898240 +-------------+
             /           |Cylinder #511|
   +--------+   5.886720 +-------------+
   |        |            |             |
   |   SD   |            .             .
   |  CARD  |            .             .  /---+------------+    /+------------+
   |        |            |             | /    |  Track #1  |   / |  1 Track   |
   +--------+     11520  +-------------+/     |- - - - - - |--/  | 5760 words |
             \           | Cylinder #0 |      |  Track #0  |     |   DP-RAM   |
              \    0000  +-------------+ - - -+------------+- - -+------------+




*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include "hps_0.h"
#include <signal.h>
//
//
void init_HW(void);
void startup_leds(void);
void PRESET_one_SECTOR(void);
void print_track(int point_to_track);
void print_sector(void);
void print_binary_16bit_LSB( unsigned short ibit16);
void make_header_CRC(void);
void make_data_CRC(void);
//
void make_bad_sector_file(void);
void make_rl_structure_in_ram(void);
void make_bootsector(void);
//
void WRITE_drive_to_FPGA(int point_to_track);
void READ_drive_from_FPGA(int point_to_track);
void read_DSK(void);
//
void WRITE_to_SD_Card(void);
void write_DEC(void);
void write_cylinder_DSK(void);
void wait_for_ready(void);
void write_DSK(void);
void reorder_track(int point_to_track);
void show_all_header_in_track(int point_to_track);
void check_header(int point_to_track);
void find_PR1(int point_to_track);
void squeeze_track(int point_to_track);
void check_cylinder(int point_to_track);
void recover_cylinder(int point_to_track);
//
void send_drive_command(unsigned short drivecommand);
void get_status(void);
void print_status(unsigned short drivestatus);
void init_drive(void);
void sigintHandler(int sig_num);
void write_one_track(int point_to_track);
void seek_to_cyl(int cyl);
//
typedef unsigned char byte;
//
#define HW_REGS_BASE ( ALT_STM_OFST )             // axi_lw
#define HW_REGS_SPAN ( 0x04000000 )               // Bridge span
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )
#define ALT_AXI_FPGASLVS_OFST (0xC0000000)        // axi_master
#define HW_FPGA_AXI_SPAN (0x40000000)             // Bridge span
#define HW_FPGA_AXI_MASK ( HW_FPGA_AXI_SPAN - 1 )
//
//
#define  RL01SIZE    (256 * 80 * 256)
#define  RL02SIZE    (512 * 80 * 256)
//
// Bit 9 = volume check , Bit 7 = Drive Type , Bit 6 = in action current head
#define RL01_OK 0x021D           // Octal:001035 = Drive Status, RL01 is ready/head_0
#define RL02_OK 0x029D           // Octal:001235 = Drive Status, RL02 is ready/head_0
//
#define CYL_size 11520           // One track size,       16Bit words
#define DPR_size 5760            // Dual-Portet-RAM size, 16Bit words
#define RL01_size 255            // RL01 = 256 cylinder ( 0 - 255 )
#define RL02_size 511            // RL02 = 512 cylinder ( 0 - 511 )
#define SEC_size_c 288           // byte:    Sector size, including header/crc/servo  8Bit
#define SEC_size_i 144           // integer: Sector size, including header/crc/servo 16Bit
#define SEC_size_l 72            // long:    Sector size, including header/crc/servo 32Bit
#define track_size_c 11520       //  = SEC_size_c 288    *40
#define track_size_i  5760       //  = SEC_size_i 144    *40
#define sector_per_track 39      // one track contais 40 sectors, 0-39
#define retry_limit 3            // Limit
#define TRUE  1
#define FALSE 0
//
// 4 Unit-Size + Base-addresses 16bit in RAM for the RL-Units
#define RAMi 12000000             // Used RAM-Size integer
#define RAMs 24000000             // Used RAM-Size short integer
#define RAMb 48000000             // Used RAM-Size byte
#define RL0_base 0                // Byte: 0
#define RL1_base 6000000          // Byte: 12000000
#define RL2_base 12000000         // Byte: 18000000
#define RL3_base 18000000         // Byte: 36000000
#define RL0SN_1 0x0AF3            //0x2803 
#define RL0SN_2 0x07A2            //0x1954 myself
#define RL1SN_1 0x08FE            //0x2302 
#define RL1SN_2 0x0781            //0x1921 mother
#define RL2SN_1 0x08A2            //0x2210 
#define RL2SN_2 0x077D            //0x1917 father
#define RL3SN_1 0x07D4            //0x2004
#define RL3SN_2 0x07A4            //0x1956 sister
//------------------------------------------------------------------------------------------------------
//
/*        *********************** Global Definitions **********************        */
//
//------------------------------------------------------------------------------------------------------
union rld {                                       // ****** one RL01/2 sector *************
       unsigned char  rl02c[512];                 // Access to one Sector via 296 bytes or
       unsigned short rl02i[256];                 // 144 16Bit words  , alligned to 512/256
       unsigned int   rl02l[128];
};
union  rld SECTOR __attribute__ ((aligned(4)));   // define a union of type SECTOR
union  rld *u_rl02ptr;                            // pointer to union.
//------------------------------------------------------------------------------------------------------
union rlt {
       unsigned char  rl_drive_c[RAMb];           // ******* RL02 Structure @ RAM/=union ********
       unsigned short rl_drive_i[RAMs];           // Virtual access to 512 cylinders(head 0 and 1)
       unsigned int   rl_drive_l[RAMi];           // 2* 40 sectors = 11520 16 bit * 512 = 5898240/unit
};
//union  rlt RLDRIVE;                             // define a union of type RLDRIVE
union  rlt RLDRIVE __attribute__ ((aligned(4)));  // define a union of type RLDRIVE
union  rlt *u_rl02_drive_ptr;                     // pointer to union
//------------------------------------------------------------------------------------------------------
int fd;                                           // Hold FPGA address
void *virtual_base;                               // Virtual axi-lw addr that maps to physical
void *axi_virtual_base;                           // Virtual axi-master addr that maps to physical
void *PIO_0_addr;                                 // PIO-0 address
void *PIO_1_addr;                                 // PIO-1 address
void *PIO_2_addr;                                 // PIO-2 address
void *DPR;                                        // Dual Ported Ram address
void *DPR_addr;                                   // Dual Ported Ram address with AXI-Master
//void *UART0;                                    // UART_0 address
//FILE* fp;
//------------------------------------------------------------------------------------------------------
unsigned short int rl_command    =   0x8001;
unsigned short int rl_recover    =   0x8001;
unsigned short int rlstatus =        0x1234;      // should be RL01_OK = 0x021D
//
unsigned short int header_index =    3;           // Header index =3                 -->6
unsigned short int data_start =     10;           // + 7, = +header=3 +PD1=1 +PR2=3  -->13
unsigned short int data_CRC =      138;           // + 128                           -->141
unsigned short int clone_offset =    0;
//
unsigned short int offset   =        3;
unsigned short int RL_unit  =        0;           // configured  RL unit(s) ( Statisch )
unsigned short int RL_Nr    =        0;           // current used Drive Number
unsigned short int RL_Nr_old    =    0;           // Used Drive Number before
unsigned short int RL_match =        0;           // Match for RL Unit binary notation
unsigned short int RL_match_old =    0;           // Used Match before
unsigned short int cylinder     =    0;
unsigned short int ist_cylinder =    0;           // current used cylinder
unsigned short int soll_cylinder =   0;           // calculated cylinder
unsigned short int from_cylinder =   0;           //
unsigned short int ist_head  =       0;           // current used head
unsigned short int soll_head =       0;           // calculated head
unsigned short int pattern   =  0x1111;
//unsigned short int head=0;
int SDRAM                   = 11796480;           // Used bytes in RAM for one RL-unit
unsigned short MAXCYL       =      511;           // cylinder, RL01/Rl02
//
short int mode=0;                                 // System operating mode
//
unsigned char DEBUG      = 0;                     // DEBUG PURPOSE
unsigned char Fehler     = 0;
unsigned char DRR_Fehler = 0;
char c;
unsigned char cx;
unsigned char RL=1;                               // 0=RL01 , 1=RL02
unsigned char format=0;                           // Init(format) disk set
unsigned char dl0=0;                              // Unit 0
unsigned char dl1=0;                              // Unit 1
unsigned char dl2=0;                              // Unit 2
unsigned char dl3=0;                              // Unit 3
unsigned char found=0;
unsigned char writemode=0;
//
unsigned char RL_drive_nr_changed=0;              // Flag to indicate a RL-drive UNIT number change was done
//
unsigned char priwhile = 0;
unsigned char secwhile = 0;
//
int dl0_cnr=0, dl1_cnr=0, dl2_cnr=0, dl3_cnr=0;
//
int Cylinder_nr=0;                               // Cylinder number , 0 - 255 ( RL02 )
int Cylinder_nr_diff = 0;                        // Difference to last cylinder_adress
int RAM_cyl_addr;                                // Address @RAM , (Cylinder_nr * CYL_size)
//
int BASE = RL0_base;
int DEST = RL1_base;
int rlBASE;
int RAM_Address = RL0_base;
int unit_base;
int retry     = 0;
int DPR_retry = 0;
//
char myfile2[80];
char myfile3[80];
char filehead[10];
//
//
/*******************************************************************************************************/
//
//
//
//
void init_HW(void)
{
  //---------------------------------------------------------------------------------------------------
  // === get FPGA addresses ===
  // Open /dev/mem
  if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        printf( "ERROR: could not open \"/dev/mem\"...\n" );
        fflush(stdout);
        close( fd );
  return; }
  //---------------------------------------------------------------------------------------------------
  // Get virtual addr that maps to physical
  virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );
  if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        fflush(stdout);
        close( fd );
  return; }
  axi_virtual_base = mmap( NULL, HW_FPGA_AXI_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, ALT_AXI_FPGASLVS_OFST );
  //----------------------------------------------------------------------------------------------------
  //
  // Get the addresses that maps to the FPGA control 
  PIO_0_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_0_BASE ) 
                                & ( unsigned long)( HW_REGS_MASK ) );
  PIO_1_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_1_BASE ) 
                                & ( unsigned long)( HW_REGS_MASK ) );
  PIO_2_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_2_BASE ) 
                                & ( unsigned long)( HW_REGS_MASK ) );
  DPR =  virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + DPR_BASE )
                      & ( unsigned long)( HW_REGS_MASK ) ); 
  DPR_addr =   axi_virtual_base + ( ( unsigned long  )( DPR_BASE ));  // This works with DPR !!!
//  UART0 = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UART_0_BASE )
//                      & ( unsigned long)( HW_REGS_MASK ) );  
  if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        fflush(stdout);
        close( fd );
        return; }
  //-----------------------------------------------------------------------------------------------------
  // 
}
//
//
void PRESET_one_SECTOR(void) {
  // initialize data for one sector used for test and reference purpose.
  int i;
  header_index = 3;                                                   // **** Set ****
  data_start = header_index + 7;                                      // **** Set ****
  data_CRC = header_index + 135;                                      // **** Set ****
  unsigned short mysector[]=
  { 0x0000, 0x0000, 0x8000,                                           //  PR1,header_index=3
    0x0000, 0x0000, 0x0000,                                           //  Header
    0x0000,                                                           //  PD1
    0x0000, 0x0000, 0x8000,                                           //  PR2
    0x0000, 0x0000,                                                   //  Data 00-01
    0xFF00, 0xFF00, 0xFF00, 0xFF00, 0xFF00, 0x0000, 0x0000, 0x0000,   //  Data 02-09
    0x3333, 0x3333, 0x3333, 0x3333, 0x3333, 0x0000, 0x0000, 0x5500,   //  Data 10-17
    0x5555, 0x5555, 0x5555, 0x5555, 0x0055, 0x0000, 0x0000, 0x9249,   //  Data 18-25
    0x4924, 0x2492, 0x9249, 0x0024, 0x0000, 0x0000, 0x9123, 0x23DC,   //  Data 26-33
    0xDC91, 0x9123, 0x00DC, 0x0000, 0x0000, 0x8080, 0x8080, 0x8080,   //  Data 34-41
    0x8080, 0x8080, 0x0000, 0x0000, 0xE700, 0xF39C, 0x9CE7, 0xE7F3,   //  Data 42-49
    0xF39C, 0x0000, 0x0000, 0x6300, 0xF18C, 0x8C63, 0x63F1, 0xF18C,   //  Data 50-57
    0x0000, 0x0000, 0x7F00, 0x7F7F, 0x7F7F, 0x7F7F, 0x7F7F, 0x007F,   //  Data 58-65
    0x0000, 0x0000, 0x0D0A, 0x5453, 0x4C45, 0x204C, 0x4944, 0x2052,   //  Data 66-73
    0x4F56, 0x2052, 0x5345, 0x4920, 0x5453, 0x4B20, 0x4952, 0x4745,   //  Data 74-81
    0x5520, 0x444E, 0x4B20, 0x4945, 0x454E, 0x2052, 0x4547, 0x5448,   //  Data 82-89
    0x4820, 0x4E49, 0x0D0A, 0x2020, 0x4D49, 0x4741, 0x4E49, 0x2045,   //  Data 90-97
    0x5449, 0x4920, 0x2053, 0x4157, 0x2052, 0x4E41, 0x2044, 0x4F4E,   //  Data 98-105
    0x4F42, 0x5944, 0x4720, 0x414F, 0x2053, 0x4854, 0x5245, 0x2045,   //  Data 106-113
    0x0A20, 0xFF0D, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF,   //  Data 114-121
    0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x0000,                   //  Data 122-127
    0x6588,                                                           //  Data 128 = CRC
    0x0000,                                                           //  129 = PD2           
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,   //  130-137=Zero
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,   //  138-145=Zero
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000 }; //  146-153=Zero
	//
	//
	for (i = 0; i < 256; i++ ){ SECTOR.rl02i[i] = 0x0000; }             // clear buffer
    //
	if(writemode == TRUE) {	
		for (i = 0; i < 150; i++ ){ SECTOR.rl02i[i] = mysector[i]; }       // Load buffer
		for (i = data_start; i < 137; i++ ){ SECTOR.rl02i[i] = pattern; }  //  and Set buffer
	}else{
		for (i = 0; i < 150; i++ ){ SECTOR.rl02i[i] = mysector[i]; }       // Load buffer
	}
	make_data_CRC();
	//printf("\r\n CRC=%04X \n\r", SECTOR.rl02i[data_CRC]);              // must be 0X6588
    SECTOR.rl02l[100]=0x2E575757; 
    SECTOR.rl02l[101]=0x31504450;  
    SECTOR.rl02l[102]=0x2E594731;  
    SECTOR.rl02l[103]=0x204D4F43; 
    SECTOR.rl02l[127]=0x45444E45;                                     // "ENDE" = Indicator
}
//
//
void startup_leds(void)
{
int loop_count;
int led_direction;
int led_mask;
loop_count = 0;
led_mask = 0x01;
led_direction = 0; // 0: left to right direction
    //
    while(loop_count < 3 )  {
      *(uint32_t *)PIO_0_addr = led_mask;
      usleep( 20*1000 );
      if (led_direction == 0){
            led_mask <<= 1;
            if (led_mask == (0x01 << (PIO_0_DATA_WIDTH-1)))
                 led_direction = 1;
        }else{
            led_mask >>= 1;
            if (led_mask == 0x01){ 
                led_direction = 0;
                loop_count++;
            }
        }        
    }
}
//
//
void print_track(int point_to_track) {
    int i,j;
    printf("\n\r print track Adresse: %d   ", point_to_track); 
    point_to_track = point_to_track*2;
    printf("\n\r------------------------------------------------------------------\n\r");
    for (i = 0; i < 40; i++ ) {
        for (j = point_to_track; j < point_to_track+288; j++ ) {
            printf("%c",SECTOR.rl02c[j]); fflush(stdout);
        }
        point_to_track = point_to_track + SEC_size_c ;
        printf("\n\r=========%d\n\r",i); fflush(stdout);
    }
    printf("\n\r------------------------------------------------------------------\n\r");
    
}
void print_sector(void){
 int j;
 printf("\n\r------------------------------------------------------------------\n\r");
 for (j = 0; j < 256; j++ ) {
    printf("%c",SECTOR.rl02c[j]);
 }
 printf("\n\r------------------------------------------------------------------\n\r");
}
//
//
void print_binary_16bit_LSB( unsigned short ibit16){
// Representation: LSB on right site ( PDP-11 like)
 int i;
  for (i = 0; i < 16; i++ ){
       if(0x8000 & ibit16 ) {               // Test Bit 15
          printf("1");
       }else {
          printf("0");
       }
       if((i==3) | (i==7) | (i==11)) {
          printf(" "); 
       }  
   ibit16 = ibit16 << 1;
  }
}
//
//
//- calcCRC16r ------------------------------------------------------
unsigned short int calcCRC16r(unsigned short int crc, unsigned short int c, unsigned short int mask)
//
// Note: This smart C-Code was not written by myself.
// Reference: http://www.mikrocontroller.net/topic/12177#2274632
{
  unsigned char i;
  for(i=0;i<8;i++)
  {
    if((crc ^ c) & 1) { crc=(crc>>1)^mask; }
    //if((crc = crc  ^ c) & 1) { crc=(crc>>1)^mask; }
    else crc>>=1;
    c>>=1;
  }
  return (crc);
}
//
//
void make_header_CRC(void){
  unsigned short int DEVICE_CRC16 = 0;
  // Header - Word 1 of 3  ( data )
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[header_index*2],0xA001);   //HSB
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[header_index*2+1],0xA001); //LSB
  // Header - Word 2 of 3  ( always 0 )
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[header_index*2+2],0xA001); //HSB
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[header_index*2+3],0xA001); //LSB
  // Header - Word 3 of 3  -> Header-CRC
  SECTOR.rl02i[header_index+2]=DEVICE_CRC16;
}
//
//
void make_data_CRC(void){
  unsigned short int i, MSB, LSB;
  unsigned short int DEVICE_CRC16;
  //
  DEVICE_CRC16 = 0;                             // preset Data-CRC
  //
  for (i = data_start; i < data_CRC; i++ ){
    MSB = i<<1;      // = i*2
    LSB = MSB + 1;
    DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[MSB],0xA001);
    DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[LSB],0xA001);
  }
  SECTOR.rl02i[data_CRC] = DEVICE_CRC16;       // SET DATA-CRC
}
//
//
void make_bad_sector_file(void) {
// reconstruct error free RL Cartridge (EF)
   unsigned short int j = data_start, i=0;
   //
   SECTOR.rl02i[j]   = RL0SN_1;                          // 0,1 = Cartridge SN
   SECTOR.rl02i[j+1] = RL0SN_2;                          // 0,1 = Cartridge SN
   SECTOR.rl02i[j+2] = 0x0000;                           // 2 = unused
   SECTOR.rl02i[j+3] = 0x0000;                           // 3 = Written with Zeros for Data Cartridge
   SECTOR.rl02i[j+4] = 0xFFFF;                           // 4 = Ones until End of sector = Error free
   for (i = j+4; i < 256; i++ ){
      if( i > data_start +128) {
         SECTOR.rl02i[i] = 0x000;
      } else {
          SECTOR.rl02i[i] = 0xFFFF;
      }
   }
   make_data_CRC();
}
//
//
void make_rl_structure_in_ram(void) {
// +
// construct full RL01/RL02 image in Memory ( union = SD RAM )
// the idea behind this routine is to dump the memory contents in pieces of 512 byte
// to the SD-Card after constructing the RL01 image in Memory.
// -
unsigned short int RL_sector, RL_cylinder, i;
short int temp;
int nr=0;
 for (RL_cylinder = 0; RL_cylinder < MAXCYL; RL_cylinder++ ) {
    //
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) { // construct 40 sectors @ head 0
        temp = 0;
        temp = RL_cylinder<<7;                            // Set RL-Cylinder address
        temp = temp | RL_sector;                          // Set RL-Sector
        temp = temp &~0x40;                               // Clear = select head-0
        SECTOR.rl02i[header_index] = temp;                // >> SET <<
        make_header_CRC();                                // build header CRC
		//
        if((RL_sector == 0) & (RL_cylinder == 0)){        // >>>>> SET:  make sector 0 <<<<<<
           make_bootsector();}
		//
        for(i = 0; i< SEC_size_i; i++) {
            RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
        }
        if((RL_sector == 0) & (RL_cylinder == 0)){        // >>>> RESET: make sector 0 <<<<<<
            PRESET_one_SECTOR(); 
        }
        nr = nr + SEC_size_i;
    }
    //
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {  // construct 40 sectors @ head 1
        temp = 0;
        temp = RL_cylinder<<7;                             // Set RL-Cylinder address
        temp = temp | RL_sector;                           // Set RL-Sector
        temp = temp | 0x40;                                // Set = select head-1
        SECTOR.rl02i[header_index] = temp;                 // >> SET <<
        make_header_CRC();                                 // build header CRC
        for(i = 0; i< SEC_size_i; i++) {
            RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];     // Copy track into RAM
        }
        nr = nr + SEC_size_i;
        }
    }
   // RT-11 command to get contents of RL01 Bad Sector file: dump/term/only:23730 dl0:
   //
   if(writemode == FALSE) { make_bad_sector_file(); }
   //
   RL_cylinder = MAXCYL;                                  // point to last cylinder
   //
   //
   for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {    // construct 40 sectors @ head 0
        temp = 0;
        temp = RL_cylinder<<7;                            // Set RL01-Cylinder address
        temp = temp | RL_sector;                          // Set RL01-Sector
        temp = temp &~0x40;                               // Clear = select head-0
        SECTOR.rl02i[header_index] = temp;                // >> SET <<
        make_header_CRC();                                // build header CRC
        for(i = 0; i< SEC_size_i; i++) {
            RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
        }
        nr = nr + SEC_size_i;
    }
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {  // construct 40 sectors @ head 1
        temp = 0;
        temp = RL_cylinder<<7;                            // Set RL-Cylinder address
        temp = temp | RL_sector;                          // Set RL-Sector
        temp = temp | 0x40;                               // Set = select head-1
        SECTOR.rl02i[header_index] = temp;                // >> SET <<
        make_header_CRC();                                // build header CRC
        for(i = 0; i< SEC_size_i; i++) {
            RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
        }
        nr = nr + SEC_size_i;
    }
 }
//
//
void make_bootsector(void) {
 short int i;
 unsigned short bootsector[]=
 { 0x00A0, 0x0005, 0x0104, 0x0000, 0x0000, 0x4310, 0x9C10, 0x0100,       // * ..........C....*
   0x0837, 0x0024, 0x000D, 0x0000, 0x0A00, 0x423F, 0x4F4F, 0x2D54,       // *7.$.......?BOOT-*
   0x2D55, 0x6F4E, 0x6220, 0x6F6F, 0x2074, 0x6E6F, 0x7620, 0x6C6F,       // *U-No boot on vol*
   0x6D75, 0x0D65, 0x0A0A, 0x0080, 0x8BDF, 0xFF74, 0x80FD, 0x941F,       // *ume....._.t.}...*
   0xFF76, 0x80FA, 0x01FF, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000 };     // *v.z.............*
    //
	    //
		for (i = data_start; i < 256; i++ ) {
			SECTOR.rl02i[i] = 0x0000;                                             // clear data area
		}
		for (i = 0; i < 40; i++){
			SECTOR.rl02i[i+data_start] = bootsector[i];                           // init Sector
		}
		make_data_CRC();
        //
}
//
//
void WRITE_drive_to_FPGA(int point_to_track){
  //
  // FPGA Dual-Ported-RAM size: 40 x SEC_size 16bit words = 5760 16bit words/track
  // This routine writes one sector from union RLDRIVE.rl_drive_i to FPGA/DP-RAM
  //                               ##################
  //                               ### RAM-->FPGA ###
  //                               ##################
  //
  //if((DEBUG == TRUE) & (OFFLINE == TRUE)){
  //    printf("\n\r>>> RAM -> FPGA/DPR @Base: %d  = Track-Address: %d \n\r", BASE, point_to_track); }
  //
  memcpy((void *)(DPR_addr), &RLDRIVE.rl_drive_i[point_to_track], SEC_size_c * 40);
  //
}
//
//
void READ_drive_from_FPGA(int point_to_track){
    //
    // FPGA Dual-Ported-RAM size: 40 x SEC_size 16bit words = 5760 16bit words/track
    // This routine reads one sector from FPGA/DP-RAM into union RLDRIVE.rl_drive_i
    //                               ##################
    //                               ### FPGA-->RAM ###
    //                               ##################
    //
    //if((DEBUG == TRUE) & (OFFLINE == TRUE)){
    //   printf("\n\r<<< RAM <- FPGA/DPR @Base: %d  = Track-Address: %d \n\r", BASE, point_to_track); } 
    //
    //
	DPR_retry = 0;
	DRR_Fehler = TRUE;
    do{         
        memcpy(&RLDRIVE.rl_drive_i[point_to_track], (void *)(DPR_addr), SEC_size_c * 40);
        check_header(point_to_track);        //*==* 
    } while ( DRR_Fehler == TRUE); 
	if (DPR_retry <2) { find_PR1(point_to_track); }
}
//
//
//
//
void read_DSK(void) {
    // Read .DSK file
    FILE    *infile = 0;
    byte sectorbuf[256];
    int loops = SDRAM/288, i=0, j=0, k=0, m=0;
    infile = fopen(myfile2, "rb");
    if(infile == NULL) {
        printf ("\n\n\n\r\x07	ERROR open/read image .DSK file %s \n\r", myfile2);
        printf ("	FIX THIS PROBLEM AND RESTART\n\r\n");
        fflush(stdout);
        *(uint32_t *)PIO_1_addr = 0x0000;
        exit(0);
    }
    i=unit_base;
    for(j=0; j<loops; j++) {                  
        fread(sectorbuf , 1, 256, infile);                           // read one sector
        for(m=0; m<256; m++) {
            SECTOR.rl02c[m + 20] = sectorbuf[m];                     // Copy received sector-buffer to sector
        }
        make_data_CRC();                                             // make Data CRC
        //
        for(k = data_start; k <= data_CRC; k++) {       
            RLDRIVE.rl_drive_i[i+k] = SECTOR.rl02i[k];               // copy sector to RAM(union)
        }
        i=i+SEC_size_i;
    }
    fclose(infile);
    PRESET_one_SECTOR();
}
//
//
void wait_for_ready(void) {
	int count = 0;
	while (!(*(uint32_t *)PIO_1_addr & 0x10000)) {                         //Drive ready ?
        usleep( 200*1000 );
		if(count == 3) { 
			printf("\n\r\n Wait for drive becomes ready..");
		}
		if(count > 3) { printf("."); fflush(stdout); }
		count++;
    }	
}
//
//
void write_DSK(void) {
    //
    // Write RL memory image to the .DSK file
    //
    FILE    *fptr = 0;
    byte sectorbuf[288];
    int DATAOFFS = (data_start + clone_offset)*2;
    int loops = SDRAM/288, i=0, j=0, k=0, l=0;
    //        = 40960
    fptr = fopen(myfile2, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile2);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    i=BASE;             // ?? i=unit_base *2;
    for(j=0; j<loops; j++) {
        //
        for(l = 0; l< SEC_size_c; l++) {                           // copy
            sectorbuf[l] = RLDRIVE.rl_drive_c[i+l];                // sector
        }
        if (sectorbuf[DATAOFFS - 1] & 0x40)  {                     // Daten um 1 Bit verschieben
            for (k = DATAOFFS + 256; k >= DATAOFFS - 1; k--) {
                sectorbuf[k] = (sectorbuf[k] << 1) | (sectorbuf[k - 1] >> 7);
            }
        }
        fwrite(sectorbuf + DATAOFFS, 1, 256, fptr);
        i=i+288;        
    }
    fclose(fptr);       
}
//
//
void write_cylinder_DSK(void) {
    //
    // Write RL memory image to the .DSK file
    //
    FILE    *fptr = 0;
    byte sectorbuf[288];
    int DATAOFFS = (data_start + clone_offset)*2;
    int i=0, j=0, l=0;
    //
    fptr = fopen(myfile3, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile3);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    } 
    i= BASE + (Cylinder_nr *  (CYL_size*2) );
	//i= BASE;
    //printf("\n\rwrite Cylinder_1,   RAM Adress: %d  ",i);
    //
    //
    for(j=0; j<80; j++) {                            // 80 sectoren/track
        //
        ////////////////////////////////////////////////////////////////////
        for(l = 0; l< SEC_size_c; l++) {                           // copy
            sectorbuf[l] = RLDRIVE.rl_drive_c[i+l];                // sector
        } //////////////////////////////////////////////////////////////////
        //                                           
        fwrite(sectorbuf + DATAOFFS, 1, 256, fptr);                // write 
        //fwrite(sectorbuf , 1, 256, fptr);                        // write 
        i=i+288;        
    }
    fclose(fptr);       
}
//
//
//
//
void reorder_track(int point_to_track) {
    //
    // Karfreitag im Zeichen von Corona und es nimmt kein Ende mit 
    // dieser Pandemie. Grausam und mich macht es so traurig weil
    // so viele ältere Menschen sterben müssen und der Generations-
    // Konflikt immer schlimmer wird. 
    // - Beim Lesen eines tracks weiß man erstmal nicht wo sector 0 ist,
    // also muß man die 40 sectoren eines tracks aufsteigend von 0 - 39
    // ordnen, bzw sortieren. 
    //
    unsigned short int temp=0, found_sector_0=0;
    unsigned short int PR1, sector;
    short int RL_sector;
    int base, to_addr, from_addr, sizeA, sizeB;
    PR1 = header_index;
    byte sectorbuf[track_size_c];
    //
    //
    //
    temp = 0;
    base = point_to_track;
    for (RL_sector = 0;  RL_sector <=39 ; RL_sector++) {
        temp = RLDRIVE.rl_drive_i[base + PR1];                         // get Header 
        sector = temp & 0x003F;                                        // get sector
        cylinder = temp >>7;                                           // get cylinder
        if(sector == 0) { found_sector_0 = RL_sector; }                // find sector 0      
        base = base + SEC_size_i;                                      // next sector     
    }
    base = point_to_track;
    if(found_sector_0 != 0 ) {
        //
        // A) Sichern  Position 0  bis Position von gefundenen sector_0 
        from_addr = base;
        sizeA = (found_sector_0 ) * SEC_size_c;     
        memcpy((void *)(&sectorbuf),&RLDRIVE.rl_drive_i[from_addr], sizeA );
        //
        // B) Kopieren Bereich von Position gefundenen sector_0 bis sector 39
        //    nach position 0       
        from_addr = base + ((found_sector_0) * SEC_size_i);
        to_addr = base;
        sizeB = track_size_c - sizeA;
        memcpy(&RLDRIVE.rl_drive_i[to_addr], &RLDRIVE.rl_drive_i[from_addr],sizeB );
        //
        // Kopieren von A nach position von ( sector 39 - position sector_0 *1) 
        to_addr = base + ((sector_per_track - found_sector_0 +1 ) * SEC_size_i);
        memcpy(&RLDRIVE.rl_drive_i[to_addr],(void *)(&sectorbuf), sizeA );
    }else{
        //printf("\n\r Alles schon richtig geordnet \n\r");
        printf(".");
    }
    //show_all_header_in_track(point_to_track);
}
//
//
void show_all_header_in_track(int adresse) {
    int ix,jx;
    jx = adresse;
    printf("\n\roffset  [1] ,   [2] ,   [3] ,   [4] ,   [5] ,   [6] ,   [7] ,   [8] ,   [9],	CRC");
    for (ix = 0; ix < 40; ix++ ) {
        printf("\n\r[%d] =	%04X ,  %04X ,  %04X ,  %04X ,  %04X ,  %04X , %04X ,   %04X ,  %04X,	%04X", ix,
        RLDRIVE.rl_drive_i[jx+1],RLDRIVE.rl_drive_i[jx+2],
        RLDRIVE.rl_drive_i[jx+3], RLDRIVE.rl_drive_i[jx+4], 
        RLDRIVE.rl_drive_i[jx+5],RLDRIVE.rl_drive_i[jx+6],
        RLDRIVE.rl_drive_i[jx+7],RLDRIVE.rl_drive_i[jx+8],
		RLDRIVE.rl_drive_i[jx+9],RLDRIVE.rl_drive_i[jx+138+clone_offset]);
        //
        jx=jx+SEC_size_i;
    }   
    printf("\r\n\n");
    fflush(stdout);
}
//
//
void check_header(point_to_track) {
    unsigned short int temp, found, RL_sector;
    int RAMadress, RAM, base;
	//
    RAM =       point_to_track;
    RAMadress = point_to_track;
    base =      point_to_track;	
    //
	DPR_retry = DPR_retry +1;
    for (RL_sector = 0;  RL_sector <=39 ; RL_sector++) {
        found = 0;
        RAM   = base;                                      // set new RAM adress
        do {
            RAM   = RAM +1;
            found = found +1;
            temp  = RLDRIVE.rl_drive_i[RAM];
        }while((temp != 0x8000) & ( found < 20));       
        if(found > 8) {			                                     // >8
			if(DPR_retry >= retry_limit+3) {
			    printf("\n\r\n   	FATAL header Read-Error, after %d retries \r\n", DPR_retry);	
				printf("\n\r            cylinder:%d , sector: %d ", (RAMadress/CYL_size),RL_sector);
				show_all_header_in_track(RAMadress);
				fflush(stdout);
                DRR_Fehler = FALSE;
                break;
            }				
		    if(DPR_retry >= retry_limit) {                           // retry count 
				printf("\n\r\n    Header Read-Error after %d retries , retry \r\n", DPR_retry); 
			    //show_all_header_in_track(point_to_track);
				usleep( 50*1000 );
                DRR_Fehler = TRUE;
                break;
			}			
            usleep( 50*1000 );
            DRR_Fehler = TRUE;
            break;
        } else {
            DRR_Fehler = FALSE;
        }
        base = base + SEC_size_i;                          // next sector
    }       
}
//
//
void find_PR1(int point_to_track) {
/*
    In Zeiten von Pandemie und Lock-Down Nr. 2. 
*/
    unsigned short int temp, found, RL_sector;
    int RAMadress, RAM, base;
    RAM =       point_to_track;
    RAMadress = point_to_track;
    base =      point_to_track;	
    //
    for (RL_sector = 0;  RL_sector <=39 ; RL_sector++) {
        found = 0;
        RAM   = base;
        do {
            RAM   = RAM +1;
            found = found +1;
            temp  = RLDRIVE.rl_drive_i[RAM];
        }while((temp != 0x8000) & ( found < 20));
        //
        clone_offset = found - 2;                                        // calculate current clone_offset
        if(found > 8) {
            printf("\n\r\n       ------- Fatal Header ERROR ------ ");
            printf("\n\r            cylinder:%d , sector: %d ", (RAMadress/CYL_size),RL_sector);
            show_all_header_in_track(RAMadress);
            fflush(stdout);
            exit(0);
        }
        if(found > 2) {
            squeeze_track(base); 
        }else{
            clone_offset = 0;
        }
        base = base + SEC_size_i;                       // next sector 
    }
    clone_offset = 0;
    //
    header_index = 3 + clone_offset;                    // add clone_offset       
    data_start =  10 + clone_offset;                    //  because in clone mode
    data_CRC =   138 + clone_offset;                    //   MFM start is 6 bytes earlier 
}
//
//
/*
void check_header(point_to_track) {
	// todo:
	// Funktioniert so nicht , also zusmmen mit find_PR1
	// Keine Zeit und keine Lust mehr ..... ist also was für todo
	//
    unsigned short int temp, found, RL_sector;
    int RAMadress, RAM, base;
    RAM =       point_to_track;
    RAMadress = point_to_track;
    base =      point_to_track;	
    //
    RAM =  point_to_track;
    base = point_to_track;
    //
	DPR_retry = DPR_retry +1;
    for (RL_sector = 0;  RL_sector <=39 ; RL_sector++) {
        found = 0;
        RAM   = base;                                      // set new RAM adress
        do {
            RAM   = RAM +1;
            found = found +1;
            temp  = RLDRIVE.rl_drive_i[RAM];
        }while((temp != 0x8000) & ( found < 20));       
        if(found > 8) {			                           // >8 Error
		    if(DPR_retry >= retry_limit) {                 // retry count 
				printf("\n\r    Header Read-Error after %d retries , retry ", DPR_retry); 
			}
			if(DPR_retry >= retry_limit+3) {
			printf("\n\r\n   	FATAL header Read-Error, after %d retries \r\n", DPR_retry);	
				printf("\n\r            cylinder:%d , sector: %d ", (RAMadress/CYL_size),RL_sector);
				show_all_header_in_track(RAMadress);
				fflush(stdout);
                DPR_retry = 0;
				DRR_Fehler = FALSE;
				break;
			}				
            usleep( 100*1000 );
            DRR_Fehler = TRUE;
        } else {
            DRR_Fehler = FALSE;                         // OK !
			if(found > 2) {
				squeeze_track(base); 
			}else{
				clone_offset = 0;
			}						
        }
        base = base + SEC_size_i;                       // next sector
    }
    clone_offset = 0;
    //
    header_index = 3 + clone_offset;                    // add clone_offset       
    data_start =  10 + clone_offset;                    //  because in clone mode
    data_CRC =   138 + clone_offset;                    //   MFM start is 6 bytes earlier 	
}
*/
//
//
//
//
void squeeze_track(int point_to_track) {
    int base, to , from, size ;
    base = point_to_track;
    to   = base ;
    from = base + clone_offset;
    size = (SEC_size_i)*2;
    memmove(&RLDRIVE.rl_drive_i[to],  &RLDRIVE.rl_drive_i[from], size );
}
//
//
void check_cylinder(int point_to_track) {
    unsigned short int temp=0;
    temp = RLDRIVE.rl_drive_i[point_to_track + header_index];
    //printf("\n\r check cylinder: %04X  with index: %d\n\r",temp,header_index);
    if(temp & 0x0040 ) { 
        ist_head = 1;
    }else{
        ist_head = 0;
    } 
    ist_cylinder = temp >>7;
}
//
// 
void recover_cylinder(int point_to_track) {
    unsigned short int tempo = 0;
    if((DEBUG == TRUE) & (retry >= retry_limit)){      
        printf("\n\r ERROR after %d'd retry: Seek from cylinder %d ",retry,from_cylinder);
        printf("to %d was %d ", soll_cylinder, ist_cylinder);
        fflush(stdout);
		//scanf("%c", &cx);                                                      // ---! Debug purpose !---
    }
    if ( ist_cylinder < soll_cylinder ) {                                        // case 1
            if( ((ist_cylinder+1) == soll_cylinder)&(retry >= retry_limit)) {    // the easiest case
                printf(" > retry & recover ");
            }else{
                tempo = from_cylinder - ist_cylinder;
				if(retry >= retry_limit) {
                    printf("\n\r    ERROR: Case 1, too little seek problem, retry");
					printf("\n\r    seek to target position with offset %d",tempo);
				}
                //
                rl_recover = tempo<<7;                                 // set cylinder
                rl_recover = rl_recover | 0x0001;                      // set command mode
                rl_recover = rl_recover &~0x0010;                      // set Head 0
                rl_recover = rl_recover | 0x0004;                      // to spindel
                //rl_recover = rl_recover &~ 0x0004;                   // away from spindel             
                send_drive_command(rl_recover);
                while (!(*(uint32_t *)PIO_1_addr & 0x10000)) {         //Drive ready ?
                    usleep( 50*1000 );                                 
                }                           
                usleep( 100*1000 );                                    // usleep( 180*1000 );                               
            }
    } else if (ist_cylinder > soll_cylinder ){                         // case 2
        // eg: current RL_cylinder: 363 was 364
        //tempo =  ist_cylinder - soll_cylinder;
        tempo =  ist_cylinder - from_cylinder; 
		if(retry >= retry_limit) {
			printf("\n\r    ERROR: Case 2, too far seek problem, retry");
			printf("\n\r    seek to target position with offset -%d",tempo);
		}
        //
        rl_recover = tempo<<7;                                          // set cylinder
        rl_recover = rl_recover | 0x0001;                               // set command mode.
        rl_recover = rl_recover &~0x0010;                               // set Head 0
        //rl_recover = rl_recover | 0x0004;                             // to spindel
        rl_recover = rl_recover &~ 0x0004;                              // away from spindel
        send_drive_command(rl_recover);
        while (!(*(uint32_t *)PIO_1_addr & 0x10000)) {                  //Drive ready ?
            usleep( 50*1000 );                                 
        }                           
        usleep( 100*1000 );                                             // usleep( 180*1000 );
    }   
}
//
//-----------------------------------------------------------------------------------------------------+
void send_drive_command( unsigned short drivecommand){
    *(uint32_t *)PIO_2_addr = drivecommand;                                    // command @ PIO
	//usleep( 6000 );
    *(uint32_t *)PIO_1_addr =  (mode=mode | 0x4000);                           // set Trigger
    usleep( 6000 );                                                            //  usleep( 6000 );
    *(uint32_t *)PIO_1_addr = (mode=mode&~0x4000);                             // remove Trigger
}
//
//
void get_status(void){
    rlstatus = 0;
    //usleep( 5000 );
    rlstatus = *(uint32_t *)PIO_2_addr;
    usleep( 5000 );
    //*(uint32_t *)PIO_1_addr =  (mode=mode | 0x0800);                           // Give Answer
    //usleep( 6000 );                                                            //
    //*(uint32_t *)PIO_1_addr = (mode=mode&~0x0800);                             // remove Answer
}
//
//
void print_status(unsigned short drivestatus){
	unsigned short status = drivestatus, temp;
	temp = status & 0x0007; 
	printf("\n\r\n\r"); 
	if(temp == 0x000) {
		printf("				> "); }
	printf("Load cartridge state \n\r");
	if(temp == 0x001) {
		printf("				> "); }
	printf("Spin up \n\r");
	if(temp == 0x002) {
		printf("				> "); }
	printf("Brush cycle \n\r");	
	if(temp == 0x003) {
		printf("				> "); }
	printf("Load Heads \n\r");		
	if(temp == 0x004) {
		printf("				> "); }
	printf("Seek-Track Counting \n\r");		
	if(temp == 0x005) {
		printf("				> "); }
	printf("Seek-Linear Mode (Lock ON) \n\r");
	if(temp == 0x006) {
		printf("				> "); }
	printf("Unload Heads \n\r");	
	if(temp == 0x007) {
		printf("				> "); }
	printf("Spin down \n\r");	
    //
	if(status & 0x0008) {
		printf("				> "); }
	printf("Brush Home (BH) \n\r");
	if(status & 0x0010) {
		printf("				> "); }
	printf("Heads Out (HO) \n\r");
	if(status & 0x0020) {
		printf("				> "); }
	printf("Cover OPEN (CO) \n\r");
	if(status & 0x0040) {
		printf("				> "); }
	printf("Head Selected (HS) \n\r");
	if(status & 0x0080) {
		printf("				> "); }
	printf("-reserved- \n\r");	
	if(status & 0x0100) {
		printf("				> "); }
	printf("Drive Select Error (DSE) \n\r");	
	if(status & 0x0200) {
		printf("				> "); }
	printf("Volume Check (VC) \n\r");

	if(status & 0x0400) {
		printf("				> "); }
	printf("Write Gate Error (WGE) \n\r");
	if(status & 0x0800) {
		printf("				> "); }
	printf("Spin Error (SPE) \n\r");
	if(status & 0x1000) {
		printf("				> "); }
	printf("Seek Time Out (SKTO) \n\r");
	if(status & 0x2000) {
		printf("				> "); }
	printf("Drive Write Locked \n\r");
	if(status & 0x4000) {
		printf("				> "); }
	printf("Head Current Error (HCE) \n\r");
	if(status & 0x8000) {
		printf("				> "); }
	printf("Write Data Error (WDE) \n\r");	
}
//
//
void init_drive(void){
	rlstatus = 0;
	wait_for_ready();
	printf("\n\r               Drive READY signal = TRUE ");
	//
	printf("\n\r                   Reset/Init drive ");	
	send_drive_command(0x0009);    // 0x0009
    usleep( 300*1000 );
    send_drive_command(0x0001);    // dummy
    usleep( 300*1000 );
	printf("\n\r                 Request drive status \n\r");
    do{		
		send_drive_command(0x0001); 
		get_status();
		usleep( 300*1000 );
		send_drive_command(0x0003);
		get_status();
        if(rlstatus == 0) {
			printf(".");
			fflush(stdout);
			usleep( 600*1000 );
		}
    }while (rlstatus == 0);                     
    printf("\n\r           Drive status: %4X  = ", rlstatus);
    print_binary_16bit_LSB(rlstatus);
    wait_for_ready();
	fflush(stdout);
}
//-----------------------------------------------------------------------------------------------------+
//
//
void sigintHandler(int sig_num)  { 
//  Reset handler to catch SIGINT next time. 
    signal(SIGINT, sigintHandler); 
    printf("\n\r rlemulator cannot be terminated using Ctrl+C \n\r"); 
    printf("           Press Button-1 for exit\n\r");
    fflush(stdout); 
}
//
//
//
//
//
void write_one_track(int point_to_track) {
	//
	// Einen Track schreiben: Die Zeit für einen Trck ist 25.056 ms, =usleep( 2*26*1000 );
	// erst wird die firmware ohne enabled Write Gate gestartet. Dies ist sicherheitshalber 
	// für die Synchronisation nötig. Dann werden die Daten von einen Track, = 40 sectoren
	// ins DPR geschrieben. Write gate enabled 0x0200 , und dann der Write durchgeführt.
	//
    int to;
    to = point_to_track;
    //
	//
	WRITE_drive_to_FPGA(to);                                     // Write data to DPR
	*(uint32_t *)PIO_1_addr =  (mode=mode |  0x0400);            // **** INIT: WRITE one track
	usleep( 52*1000 );                                           // wait 2 track = 2*25ms
	*(uint32_t *)PIO_1_addr = (mode=mode&~0x0400); 	             // Disable Writing one track
	usleep( 52*1000 );                                           // wait 2 track = 2*25ms	
	//
	//	
	WRITE_drive_to_FPGA(to);                                     // Write data to DPR
	*(uint32_t *)PIO_1_addr =  (mode=mode |  0x0200);            // **** Enable Write_Gate
	*(uint32_t *)PIO_1_addr =  (mode=mode | 0x0400);             // **** INIT: WRITE one track
    usleep( 52*1000 );                                           // wait 2 track = 2*25ms
    *(uint32_t *)PIO_1_addr = (mode=mode&~0x0400); 	             // Disable Writing one track
	//
	//READ_drive_from_FPGA(to);                                  // Verify purpose	
}
//
//
void seek_to_cyl(int cyl){
	unsigned short int diff;
    rl_command  = 0;
	check_cylinder(RAM_Address);                                          // get ist_cylinder
	soll_cylinder = cyl;                                                  // set cylinder
	if (soll_cylinder >= ist_cylinder ) {
		diff = soll_cylinder - ist_cylinder;
		rl_command = diff<<7;
		rl_command = rl_command | 0x0001;                                  // set command mode.		
		RAM_cyl_addr = (ist_cylinder + diff) * CYL_size;
		RAM_Address  =  BASE + RAM_cyl_addr + (soll_head*track_size_i);
		rl_command = rl_command | 0x0004;                                  // to spindel
	}else{
		diff = ist_cylinder - soll_cylinder;
		rl_command = diff<<7;
		rl_command = rl_command | 0x0001;                                  // set command mode.		
		RAM_cyl_addr = (ist_cylinder - diff) * CYL_size;
		RAM_Address  =  BASE + RAM_cyl_addr + (soll_head*track_size_i);
		rl_command = rl_command &~ 0x0004;                                 // away from spindel
	}
	if(soll_head == 1) {
		rl_command = rl_command | 0x0010;                                  // set Head_1
	}else{
		rl_command = rl_command &~0x0010;                                  // set Head 0
	}
	do {
		send_drive_command(rl_command);
		usleep( 100*1000 );
		wait_for_ready();
		check_cylinder(RAM_Address);
	} while ( soll_cylinder != ist_cylinder );
	ist_cylinder = soll_cylinder;
}
//
//
//
//
//
//
//
//
//                                            §§§§§§§§§§§§§§§§§§§§§§§§§§
//                                            §§§§§§§    MAIN    §§§§§§§
//                                            §§§§§§§§§§§§§§§§§§§§§§§§§§
int main()
{
  unsigned int operatingmode;
  unsigned int temp1, loops;
  unsigned short int old_RL_cylinder;
  unsigned short int RL_cylinder_diff;
  char buffer[10];
  rlstatus = 0;
  //unsigned char found=0; 
  //
  init_HW();
  while(priwhile == 0) {    // Primary while
        //
        PRESET_one_SECTOR();                                   // Preset sector
        *(uint32_t *)PIO_0_addr = mode;                        // Clear PIO-0
        *(uint32_t *)PIO_1_addr = mode;                        // Clear PIO-1
        priwhile = 0;
        secwhile = 0;
        //
        printf("\n\r\x1B[2J       *******>  DEC RL01/RL02 Cloner/Reader <********  \n\r");
        printf("              SoC/HPS DE10-Nano board V.2.8E                       \n\r");
        printf("                   (c) WWW.PDP11GY.COM                             \n\r");
        startup_leds();
        //
        //
        //
        // >>>>>> Check & setup Device Typ, RL01 or RL02<<<<<<<<<<<<
        if (( *(uint32_t *)PIO_1_addr) & 0x0008) {                // SW_5 @ I_ctrl[3]
           RL = 1;                                                // RL02
           rl_command = RL02_OK;
           SDRAM = 11796480;
           MAXCYL = RL02_size;
           strcpy( filehead, "RL02" );
           printf ("\n\r              >>>>> Device Type = RL02 <<<<");
        } else {
           RL = 0;                                               // RL01
           rl_command = RL01_OK;
           SDRAM = 5898240;
           MAXCYL = RL01_size;
           strcpy( filehead, "RL01" );
           printf ("\n\r              >>>>> Device Type = RL01 <<<<");
        }
        //
        // >>>>>>>>>>>>>>>>>> Check for debug mode <<<<<<<<<<<<
        if (( *(uint32_t *)PIO_1_addr) & 0x2000) {         // SW_6 @ I_ctrl[13]
           DEBUG = 1;
           printf ("\n\r              >>>>>> DEBUG-MODE = ON <<<<<<");
        } else {
           DEBUG = 0;
           printf ("\n\r              >>>>>> DEBUG-MODE = OFF <<<<<");
        }
        //
        //  
        // >>>> Check and setup available configured units <<<<<
        RL_unit = *(uint32_t *)PIO_1_addr >>4  & ~0xFFF0;
        printf ("\n\r              **** Cloning disk-drive: ");
        strcpy( myfile2, filehead);
        found = FALSE;
        if((RL_unit & 0x0001) && (found == FALSE)) {
           printf ("DL0: ");
           found = TRUE;
           strcat( myfile2, "_0-clone.dsk" );
           dl0=1;
           mode = 0x0000;                                // @  O_ctrl[13]  and O_ctrl[12]
        } 
        if((RL_unit & 0x0002) && (found == FALSE)) {
            printf ("DL1: ");
            found = TRUE;
            strcpy( myfile2, "_1-clone.dsk" );
            dl1=1;
            mode = 0x1000;                               // @  O_ctrl[13]  and O_ctrl[12]           
        } 
        if((RL_unit & 0x0004) && (found == FALSE)) {
            printf ("DL2: ");
            found = TRUE;
            strcat( myfile2, "_2-clone.dsk" );
            dl2=1;
            mode = 0x2000;                               // @  O_ctrl[13]  and O_ctrl[12]
        }       
        if((RL_unit & 0x0008) && (found == FALSE)) {
            printf ("DL3: ");
            found = TRUE;
            strcat( myfile2, "_3-clone.dsk" );
            dl3=1;
            mode = 0x3000;                               // @  O_ctrl[13]  and O_ctrl[12]           
        }
        *(uint32_t *)PIO_1_addr = mode;                          // Set Unit-number
        usleep( 100*1000 );
        //
        printf ("\n\r              ******** preset memory ******\n\r");
        BASE = RL0_base;
        make_rl_structure_in_ram();
        memcpy(&RLDRIVE.rl_drive_i[RL1_base], &RLDRIVE.rl_drive_i[BASE], SDRAM );
        memcpy(&RLDRIVE.rl_drive_i[RL2_base], &RLDRIVE.rl_drive_i[BASE], SDRAM );
        memcpy(&RLDRIVE.rl_drive_i[RL3_base], &RLDRIVE.rl_drive_i[BASE], SDRAM );       
        //
        //
        mode = mode | 0x4001;                                         // ** Preset ********************************
        *(uint32_t *)PIO_1_addr = mode;                               // ** Start, Step #1of2 = ENABLE interface **
        //
        //
        RL_Nr_old = RL_Nr;                                            // Preset
        RL_match_old = RL_match;                                      // Preset
        RAM_Address = BASE;                                           // Preset
        //
		//
        //                                                             ##################
        WRITE_drive_to_FPGA(RAM_Address );//                           ### RAM-->FPGA ###
        //                                                             ##################
        mode=mode|0x00A1;
        *(uint32_t *)PIO_1_addr = mode;
        *(uint32_t *)PIO_1_addr =  (mode=mode | 0x8000);               // enable clone-mode @O_ctrl[15]
        if(DEBUG == TRUE) {
           printf("\n\r Started with operating mode:  ");
           print_binary_16bit_LSB(mode);printf("    \r\n\n");
        }
        //
        //
        //
        //
        //                           §§§§§§§§§§§§§§§§§§§§§§§§§§
        //                           §§§§§§§  MAIN LOOP §§§§§§§
        //                           §§§§§§§§§§§§§§§§§§§§§§§§§§
        //
        //
        //signal(SIGINT, sigintHandler);                   // Prevent abort by ctrl-C
        //
        //--------------------------------
		init_drive();
        RAM_Address = BASE;
        rl_command = 0;
        READ_drive_from_FPGA(RAM_Address);
        reorder_track(RAM_Address);                                    //----//
        check_cylinder(RAM_Address);
        printf("\n\r               Drive at cylinder position: %d", ist_cylinder);
        if(ist_cylinder !=0 ) {
            Cylinder_nr = ist_cylinder;
            rl_command = Cylinder_nr<<7;                              // set cylinder
            rl_command = rl_command | 0x0001;                         // set command mode.
            rl_command = rl_command &~0x0010;                         // set Head_0
            rl_command = rl_command &~ 0x0004;                        // away from spindel
            send_drive_command(rl_command); 
            usleep( 300*1000 ); 
            //send_drive_command(0x0001);
        }
        READ_drive_from_FPGA(RAM_Address);
        check_cylinder(RAM_Address);
        printf("\n\r           Drive positioned to cylinder position : %d", ist_cylinder);
        //--------------------------------
        while(secwhile == 0) {                                        // Secondary while
            //
            printf("\n\r\n\r                  ****** Select Mode ******");
            printf("\n\r 0=exit, 1=get status, 2=clone disk, 3=read one Cylinder, 4=seek-test, 5=write : ");
            fflush(stdout);
            scanf("%d", &operatingmode); 		
            switch(operatingmode) {
				case 0:
				    mode=0x0000;
					*(uint32_t *)PIO_1_addr = mode;
					printf("\n\n\r		Servus & bis bald \n\r\n");
					fflush(stdout);
					exit(0);
				break;
                case 1:  //------------------------------------------------------------------------------------------------------
					writemode = FALSE;
                    send_drive_command(0x0003); 
                    get_status();
                    usleep( 100*1000 );
                    send_drive_command(0x0003);
                    get_status();
                    if(rlstatus == 0) {
                        printf("\n\r             Drive DL%d: is not present \n\r\n", RL_Nr);
                        fflush(stdout);
                        break;
                    }else {                     
                        printf("\n\r get drive status: %4X  = ", rlstatus);
                        print_binary_16bit_LSB(rlstatus);
						wait_for_ready();
						print_status(rlstatus);
                    }
                break;
                //
                case 2:  //------------------------------------------------------------------------------------------
					writemode = FALSE;
                    printf("\n\r ");
                    printf("\n\r Data will be saved in file: %s",myfile2);fflush(stdout);
                    old_RL_cylinder = 0;
                    soll_cylinder   = 0;
                    rl_command      = 0;
                    for (soll_cylinder = 0; soll_cylinder <=MAXCYL; soll_cylinder++ ) {
                        Cylinder_nr = soll_cylinder;
                        from_cylinder = old_RL_cylinder;
                        RL_cylinder_diff = soll_cylinder - old_RL_cylinder;           // calculate cylinder difference
                        //
                        soll_head = 0;
                        RAM_cyl_addr = (Cylinder_nr * CYL_size);
                        RAM_Address = BASE + RAM_cyl_addr + (soll_head*track_size_i); // Calculate new RAM address
                        //
                        rl_command = RL_cylinder_diff<<7;                             // set cylinder
                        rl_command = rl_command | 0x0001;                             // set command mode.
                        rl_command = rl_command &~0x0010;                             // set Head_0
                        rl_command = rl_command | 0x0004;                             // to spindel
                        if(DEBUG == TRUE){
                            printf("\n\r set_track-0: ");print_binary_16bit_LSB(rl_command); 
                            printf("  cylinder: %d", soll_cylinder); 
                            printf("  RAM_Address: %d",RAM_Address); fflush(stdout);
                        }else{
                            printf("\r Cloning Cylinder :%d",soll_cylinder);fflush(stdout);
                        }
                        do {
                            Fehler = TRUE;                                            // Preset Fehler
                            send_drive_command(rl_command);
							wait_for_ready();                  
                            usleep( 100*1000 );                                       // usleep( 180*1000 );
                            //
                            //                                                        // ##################
                            READ_drive_from_FPGA(RAM_Address);                        // ### FPGA-->RAM ###
                            //                                                        // ##################
                            //
                            check_cylinder(RAM_Address);
                            if( soll_cylinder != ist_cylinder) {
								retry = retry +1;                                     // increment retry counter
                                recover_cylinder(RAM_Address);
                            } else {
                                Fehler = FALSE;        								  // all ok
								retry = 0;
                            }  
                        } while ( Fehler == TRUE);
                        reorder_track(RAM_Address);
                        //
                        rl_command = rl_command &~0xFF80;                             // Clear Cylinder
                        rl_command = rl_command | 0x0010;                             // set Head_1
                        printf("\n\r set_track-1: ");
                        print_binary_16bit_LSB(rl_command); fflush(stdout);
                        soll_head = 1;
                        RAM_Address = BASE + RAM_cyl_addr + (soll_head*track_size_i); // Calculate new RAM address
                        do {
                            send_drive_command(rl_command);
                            usleep( 100*1000 );                                       // usleep( 150*1000 );
                            //
                            //                                                        // ##################
                            READ_drive_from_FPGA(RAM_Address);                        // ### FPGA-->RAM ###
                            //                                                        // ##################
                            check_cylinder(RAM_Address);
                        } while ( soll_head != ist_head );                            
                        reorder_track(RAM_Address);
                        old_RL_cylinder = soll_cylinder;
                        fflush(stdout);
                    }
                    write_DSK();
                    rl_command = 0xFF81;                                           // back to cylinder 0
                    rl_command = rl_command &~ 0x0004;                             // away from spindel to cylinder 0
                    send_drive_command(rl_command); 
                    usleep( 100*1000 );                                            // usleep( 180*1000 );
                    printf("\n\r Saved data in file: %s",myfile2);fflush(stdout);
                break;
                //
                case 3:  //------------------------------------------------------------------------------------------------------
					writemode = FALSE;
                    //printf("\n\r Case 3\n\r");
                    printf("\n\r Cylinder-Nr.(0 to 255 ) :");
                    scanf("%d", &temp1);
                    Cylinder_nr = temp1;
					soll_cylinder = temp1;
                    //
                    soll_head = 0;
                    RAM_Address = 0;                                               // clear
                    rl_command  = 0;
                    RAM_cyl_addr = (Cylinder_nr * CYL_size);
                    RAM_Address = BASE + RAM_cyl_addr + (soll_head*track_size_i);  // Calculate new RAM address
                    rl_command = temp1<<7;                                         // set cylinder
                    rl_command = rl_command | 0x0001;                              // set command mode.
                    rl_command = rl_command &~0x0010;                              // set Head 0
                    rl_command = rl_command | 0x0004;                              // to spindel
                    printf("\n\r rl_command-1: ");print_binary_16bit_LSB(rl_command); 
                    printf("  RAM-Address:  %d",RAM_Address); fflush(stdout);
                    do {
						Fehler = TRUE;
                        send_drive_command(rl_command);
						wait_for_ready();
                        usleep( 180*1000 );
                        //
                        //                                                         // ##################
                        READ_drive_from_FPGA(RAM_Address);                         // ### FPGA-->RAM ###
                        //                                                         // ##################
                        //
                        //show_all_header_in_track();
                        check_cylinder(RAM_Address);
                        if( soll_cylinder != ist_cylinder) {
							retry = retry +1;                                     // increment retry counter
                            recover_cylinder(RAM_Address);
                        } else {
                            Fehler = FALSE;        								  // all ok
							retry = 0;
                        }  
                    } while ( Fehler == TRUE);
                    reorder_track(RAM_Address);
                    soll_head = 1;                                                 // Switch to Head 1
                    rl_command = rl_command | 0x0010;                              // set Head_1
                    rl_command = rl_command &~0xFF80;                              //
                    RAM_Address = BASE + RAM_cyl_addr + (soll_head*track_size_i);  // Calculate new RAM address
                    do {
                        send_drive_command(rl_command);
                        printf("\n\r rl_command-2: ");print_binary_16bit_LSB(rl_command); 
                        printf("  RAM-Address:  %d",RAM_Address); fflush(stdout);
                        //
						wait_for_ready();
                        usleep( 180*1000 );
                        //
                        //                                                         // ##################
                        READ_drive_from_FPGA(RAM_Address);                         // ### FPGA-->RAM ###
                        //                                                         // ##################
                        //
                        check_cylinder(RAM_Address);
                    } while ( soll_head != ist_head );    
                    reorder_track(RAM_Address);
                    strcpy( myfile3, filehead);
                    strcat( myfile3, "_cylinder-");
                    sprintf(buffer, "%d", Cylinder_nr);
                    strcat(myfile3, buffer);
                    strcat(myfile3, ".dsk");
                    write_cylinder_DSK();
                    //
                    soll_head = 0;
                    RAM_Address = 0;
                    rl_command = temp1<<7;                                         // (re)set cylinder
                    rl_command = rl_command | 0x0001;                              // set command mode.
                    rl_command = rl_command &~ 0x0004;                             // away from spindel
                    send_drive_command(rl_command);
                    printf("\n\r rl_command-3: ");print_binary_16bit_LSB(rl_command); 
                    printf("  RAM-Address:  %d",RAM_Address); fflush(stdout);
                    usleep( 150*1000 );
                    printf("\n\r Saved data in file: %s",myfile3);fflush(stdout);
                    //}
                break;
                //
                case 4: //------------------------------------------------------------------------------------------------------
					writemode = FALSE;
                    printf("\n\r Seek to cylinder (max = %d) :  ", MAXCYL); fflush(stdout);
                    scanf("%d", &temp1);                
                    printf("\n\r Number of loops: ");
                    scanf("%d", &loops);
                    check_cylinder(RAM_Address);
                    Cylinder_nr = temp1;
                    rl_command = Cylinder_nr<<7;                                   // set cylinder
                    rl_command = rl_command | 0x0001;                              // set command mode.
                    rl_command = rl_command &~0x0010;                              // set Head_0
                    for (soll_cylinder = 0; soll_cylinder <=loops; soll_cylinder++ ) {                        
                        rl_command = rl_command | 0x0004;                          // to spindel
                        printf("\n\%dtime: seek to cylinder %d",soll_cylinder+1,temp1);
                        send_drive_command(rl_command);
						wait_for_ready();
                        printf(" .....back to  cylinder 0");
                        rl_command = rl_command &~ 0x0004;                          // away from spindel 
                        send_drive_command(rl_command);
						wait_for_ready();
                    }                   
                break;
                //
                case 5:
					writemode = TRUE;
                    // Info
					// O_ctrl[8] , 0x0100  = logic-Analyser Pins: Test_MUX on
					// O_ctrl[9] , 0x0200  = Write Gate + Write Data enable
					// O_ctrl[10], 0x0400  = Clone-Write Mode 
					//
					printf("\n\n\r	  Write data to an emulated or real RL01/RL02 disk drive");
					printf("\n\r Note: The write operation has NOT been tested yet on a real RL02 dik drive");
					printf("\n\r When you start this write operation, you recognize that the developer of this ");
					printf("\n\r software is not responsibility if an RL02 cartridge becomes unusable.");
					printf("\n\r	 Do you agree ? (1)= Yes ..."); 
					scanf("%d", &temp1);
					if(temp1 != 1) { printf("\n\r		Bye \n\n\r"); exit(0); }
					printf ("\n\r\n\n              *********** WriteMode **********");
					printf ("\n\r              ********************************\n\r");
					//
					// 
					printf ("\n\r Enter unit nr. [0-3] of destination RL drive : ");
					scanf("%d", &temp1);
					RL_unit = temp1;
					switch(RL_unit){
						case 0:
							mode = mode | 0x0000;
						break;
						//
						case 1:
							mode = mode | 0x1000;
						break;
						//
						case 2:
							mode = mode | 0x2000;
						break;
						//
						case 3:
							mode = mode | 0x3000;
						break;
						//
					}
					*(uint32_t *)PIO_1_addr = mode;                          // Set Unit-number
                    usleep( 100*1000 );
					wait_for_ready();
					//
					printf("\n\r 1=write pattern, 2=write bad sector, 3=write .dsk-file ");
					fflush(stdout);
					soll_head   = 0;
					Cylinder_nr = 0;
					RAM_cyl_addr = (Cylinder_nr * CYL_size);
					RAM_Address = BASE + RAM_cyl_addr + (soll_head*track_size_i);  // Calculate RAM address
					check_cylinder(RAM_Address);					
					scanf("%d", &operatingmode);
					switch(operatingmode) {
						case 1:
							writemode = FALSE;             //writemode = TRUE;
                            //
                            //
							printf("\n\r Enter  Pattern, 4Hex, like A5F8: ");
							scanf("%4x", &temp1);
							pattern = temp1;
							printf("\n\r Cylinder-Nr.(0 to 255 ) :");
							scanf("%d", &temp1);
							PRESET_one_SECTOR();                               // preset sector
							make_data_CRC();                                   //
							make_rl_structure_in_ram();						   //
							//
							soll_head = 0;                                     // head 0
							printf("\r\n write pattern @ Cylinder :%d	head 0",temp1);
						    seek_to_cyl(temp1);   							   // >seek to requested cylinder
						    usleep( 100*1000 );                                //
							wait_for_ready();                                  //
							write_one_track(RAM_Address);                      // **** WRITE one track *****
							READ_drive_from_FPGA(RAM_Address);                 // Verify purpose
							//
                            soll_head = 1;                                     // head 1
			                seek_to_cyl(temp1);                                // >seek to requested cylinder
						    usleep( 100*1000 );                                //
							printf(" + head 1  ");
							wait_for_ready();                                  //							
							write_one_track(RAM_Address);                      // **** WRITE one track *****
							READ_drive_from_FPGA(RAM_Address);                 // Verify purpose
							//
                            soll_head = 0;                                     // head 0
							seek_to_cyl(0);                                    // back to cylinder 0
                            //			
						break;
						//
						case 2:
							writemode = TRUE;
							printf("\n\r	write bad sector file @ cylinder %d", MAXCYL);
							PRESET_one_SECTOR();                               // preset sector
							make_rl_structure_in_ram();                        //
							//
							soll_head = 0;                                     // head 0
							temp1 = MAXCYL;							
							seek_to_cyl(temp1);  							   // seek to cylinder
						    usleep( 100*1000 );                                //
							wait_for_ready();                                  //
							write_one_track(RAM_Address);                      // **** WRITE one track *****
							READ_drive_from_FPGA(RAM_Address);                 // Verify purpose
							//
                            soll_head = 1;                                     // head 1
			                seek_to_cyl(temp1);                                // >seek to requested cylinder
						    usleep( 100*1000 );                                //
							wait_for_ready();                                  //							
							write_one_track(RAM_Address);                      // **** WRITE one track *****
							READ_drive_from_FPGA(RAM_Address);                 // Verify purpose
							//
                            soll_head = 0;                                     // head 0
							seek_to_cyl(0);                                    // back to cylinder 0
                            //																	
						break;
						//
						case 3:
							writemode = TRUE;
							printf("\n\r	Write disk-image file");
							printf("\n\r	Enter filname: ");
							//scanf("%79s", &myfile2[0]);
							strcpy( myfile2, "RL02_0-clone.dsk" );
							printf("\n\r	Reading file: %s", myfile2);
							fflush(stdout);
							read_DSK();
							//---------------------------------------------------------------------------------------
							for (soll_cylinder = 0; soll_cylinder <=MAXCYL; soll_cylinder++ ) {
								Cylinder_nr = soll_cylinder;
								from_cylinder = old_RL_cylinder;
								RL_cylinder_diff = soll_cylinder - old_RL_cylinder;           // calculate cylinder difference
								//
								soll_head = 0;
								RAM_cyl_addr = (Cylinder_nr * CYL_size);
								RAM_Address = BASE + RAM_cyl_addr + (soll_head*track_size_i); // Calculate new RAM address
								//
								rl_command = RL_cylinder_diff<<7;                             // set cylinder
								rl_command = rl_command | 0x0001;                             // set command mode.
								rl_command = rl_command &~0x0010;                             // set Head_0
								rl_command = rl_command | 0x0004;                             // to spindel
								printf("\r\n writing Cylinder :%d	head 0",soll_cylinder);
								fflush(stdout);
                                do {
									Fehler = TRUE;								
								    send_drive_command(rl_command);
								    usleep( 50*1000 );								
								    wait_for_ready(); 
                                    READ_drive_from_FPGA(RAM_Address);
									check_cylinder(RAM_Address);
									if( soll_cylinder != ist_cylinder) {
										retry = retry +1;                                     // increment retry counter
										recover_cylinder(RAM_Address);
									} else {
										Fehler = FALSE;        								  // all ok
										retry = 0;
									}  
								} while ( Fehler == TRUE);																		
								*(uint32_t *)PIO_1_addr =  (mode=mode | 0x0100);    	      // **** Enable Test-Mux
								write_one_track(RAM_Address);                       	      // **** WRITE one track *****
							    READ_drive_from_FPGA(RAM_Address);                            // Verify purpose
								//
								rl_command = rl_command &~0xFF80;                             // Clear Cylinder
								rl_command = rl_command | 0x0010;                             // set Head_1
								printf(" + head 1  ");
								fflush(stdout);
								soll_head = 1;
								RAM_Address = BASE + RAM_cyl_addr + (soll_head*track_size_i); // Calculate new RAM address
								send_drive_command(rl_command);
								usleep( 50*1000 );								
								wait_for_ready();                           
								*(uint32_t *)PIO_1_addr =  (mode=mode | 0x0100);    	      // **** Enable Test-Mux
								write_one_track(RAM_Address);                       	      // **** WRITE one track *****
							    READ_drive_from_FPGA(RAM_Address);                            // Verify purpose	
								old_RL_cylinder = soll_cylinder;
                            }
							seek_to_cyl(0);                                                   // back to cylinder 0
						break;
					}
                break; 				
            }   
        }
    } // Primary while
    return 0; 
}
