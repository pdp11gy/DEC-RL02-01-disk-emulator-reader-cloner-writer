﻿/*
              *****************************************************************************
              *  Copyright (C) by Reinhard Heuberger  , www.pdp11gy.com                   *
              *                                                                           *
              *  All rights reserved.                                                     *
              *                                                                           *
              *  Redistribution and use in source and binary forms, with or without       *
              *  modification, are permitted provided that the following conditions       *
              *  are met:                                                                 *
              *                                                                           *
              *  1. Redistributions of source code must retain the above copyright        *
              *     notice, this list of conditions and the following disclaimer.         *
              *  2. Redistributions in binary form must reproduce the above copyright     *
              *     notice, this list of conditions and the following disclaimer in the   *
              *     documentation and/or other materials provided with the distribution.  *
              *  3. Neither the name of the author nor the names of its contributors may  *
              *     be used to endorse or promote products derived from this software     *
              *     without specific prior written permission.                            *
              *                                                                           *
              *****************************************************************************
                           RL02 Emulator for SoC HPS FPGA-environment
                                        Version V.2.8E

                     by: Reinhard Heuberger , www.PDP11GY.com, info@pdp11gy.com


                                 Data - Structure and Mapping:

                         |<--------- onboard RAM --------->|      |<- DP-RAM-->|

              / 5.898240 +-------------+
             /           |Cylinder #511|
   +--------+   5.886720 +-------------+
   |        |            |             |
   |   SD   |            .             .
   |  CARD  |            .             .  /---+------------+    /+------------+
   |        |            |             | /    |  Track #1  |   / |  1 Track   |
   +--------+     11520  +-------------+/     |- - - - - - |--/  | 5760 words |
             \           | Cylinder #0 |      |  Track #0  |     |   DP-RAM   |
              \    0000  +-------------+ - - -+------------+- - -+------------+

        The DEC RL01/RL02 disk drive did have a capacity of 5.2MB/10.4MB
        2 Heads(surfaces), 256/512 cylinder , 40 sectors/track.
        1 sector contains 128 16-bit words ( 256 Byte ) of Data
        + 12 16-Bit words for Servo/Header/CRC Data = 140 words(280 Byte)/sector.
        
        V 1.0 :  Initial version
        V 2.0 :  Full port of the MAX10 V2.0 implementation with Seral number handling. Reference :
                 https://github.com/pdp11gy/DEC-RL02-RL01-disk-emulator
        V 2.1 :  Full support of .DSK files. At write operation, the .DEC file and the .DSK
                 file will be written. At read operation, first try is to read the .DEC file. If
                 it does not exist, the .DSK file will be read. Best interface to the SIMH project.
        V 2.2 :  Bug fix. A write operation is erroneous with the result of an incorrect bit shift 
                 offset by 1. The origin of the error was in the schematics firmware module
                 My_MFM_DEcoder_SoC.bdf. The problem was temporary fixed with the C routine 
                 READ_drive_from_FPGA but not in the case of being written several times in 
                 succession on the same sector. Also, This is the last remaining schematics module
         and may be replaced by a verilog module in the next release.
                 Every known problem is fixed in version 2.2 , 05-NOV-2018               
                
                
      Some personal comments: It is a pity that cooperation does not work. Here is a peculiar competitive 
                              behavior. Everyone "cooks his own soup". That's too bad. My idea was to 
                              preserve and secure the vintage software ... nothing more ! I am already a 
                              pensioner and can not do everything alone! At least I do not understand it.
 

        V 2.3 :  No changes in the firmware. Only minor cosmetic changes / preparations.
                 The most important thing in this version is the preparation for a new version 
             with a new program, cloneRL, running also on a new PCB board. The additional program  
             will be able to clone any RL cartridges without a host computer. Everything will run 
                 in the FPGA/SOC board with recovery of the data CRC at read error if it is possible. 

        V.2.5 : New firmware and anhancement with disk clone software. No effect to the rlemulator.
        V.2.6 : firmware addon/modifications @ sector puls genarator . No effect to the rlemulator.
                debug messages modified.
		V.2.8 : New Firmware 
        
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include "hps_0.h"
#include <signal.h>
//
//
void init_HW(void);
void startup_leds(void);
void PRESET_one_SECTOR(void);
void print_sector(void);
void print_binary_16bit_LSB( unsigned short ibit16);
void make_header_CRC(void);
void make_data_CRC(void);
void make_bad_sector_file(void);
//
void SN_default(void);
void SN_write(void);
void SN_read(void);
void SN_rebuild_CRC(void);
void SN_print(void);
//
void make_offline_track0(void);
void make_rl_structure_in_ram(void);
void make_bootsector(void);
//
void WRITE_drive_to_FPGA(int point_to_track);
void READ_drive_from_FPGA(int point_to_track);
void send_drive_info( unsigned short infodrive);
void acknowledge(void);
//
void show_all_header_in_track(int point_to_track);
void find_PR1(int point_to_track);
void squeeze_track(int point_to_track);
//
void make_myfile_on_SD_Card(void);
void read_infofile_from_SD_Card(void);
void check_ID(void);
void WRITE_to_SD_Card(void);
void write_DEC(void);
void write_DSK(void);
void READ_from_SD_Card(void);
void read_DEC(void);
void read_DSK(void);
//
void RAM_align(void);
void sigintHandler(int sig_num);
//
//
typedef unsigned char byte;
//
#define HW_REGS_BASE ( ALT_STM_OFST )             // axi_lw
#define HW_REGS_SPAN ( 0x04000000 )               // Bridge span
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )
#define ALT_AXI_FPGASLVS_OFST (0xC0000000)        // axi_master
#define HW_FPGA_AXI_SPAN (0x40000000)             // Bridge span
#define HW_FPGA_AXI_MASK ( HW_FPGA_AXI_SPAN - 1 )
//
//
#define  RL01SIZE    (256 * 80 * 256)
#define  RL02SIZE    (512 * 80 * 256)
//
// Bit 9 = volume check , Bit 7 = Drive Type , Bit 6 = in action current head
#define RL01_OK 0x021D           // Octal:001035 = Drive Status, RL01 is ready/head_0
#define RL02_OK 0x029D           // Octal:001235 = Drive Status, RL02 is ready/head_0
//
#define CYL_size 11520           // One track size,       16Bit words
#define DPR_size 5760            // Dual-Portet-RAM size, 16Bit words
#define RL01_size 255            // RL01 = 256 cylinder ( 0 - 255 )
#define RL02_size 511            // RL02 = 512 cylinder ( 0 - 511 )
#define SEC_size_c 288           // byte:    Sector size, including header/crc/servo  8Bit
#define SEC_size_i 144           // integer: Sector size, including header/crc/servo 16Bit
#define SEC_size_l 72            // long:    Sector size, including header/crc/servo 32Bit
#define TRUE  1
#define FALSE 0
//
// 4 Unit-Size + Base-addresses 16bit in RAM for the RL-Units
#define RAMi 12000000             // Used RAM-Size integer
#define RAMs 24000000             // Used RAM-Size short integer
#define RAMb 48000000             // Used RAM-Size byte
#define RL0_base 0                // Byte: 0
#define RL1_base 6000000          // Byte: 12000000
#define RL2_base 12000000         // Byte: 18000000
#define RL3_base 18000000         // Byte: 36000000
#define RL0SN_1 0x0AF3            //0x2803 
#define RL0SN_2 0x07A2            //0x1954 myself
#define RL1SN_1 0x08FE            //0x2302 
#define RL1SN_2 0x0781            //0x1921 mother
#define RL2SN_1 0x08A2            //0x2210 
#define RL2SN_2 0x077D            //0x1917 father
#define RL3SN_1 0x07D4            //0x2004
#define RL3SN_2 0x07A4            //0x1956 sister
//------------------------------------------------------------------------------------------------------
//
/*        *********************** Global Definitions **********************        */
//
//------------------------------------------------------------------------------------------------------
union rld {                                       // ****** one RL01/2 sector *************
       unsigned char  rl02c[512];                 // Access to one Sector via 296 bytes or
       unsigned short rl02i[256];                 // 144 16Bit words  , alligned to 512/256
       unsigned int   rl02l[128];
};
union  rld SECTOR __attribute__ ((aligned(4)));   // define a union of type SECTOR
union  rld *u_rl02ptr;                            // pointer to union.
//------------------------------------------------------------------------------------------------------
union rlt {
       unsigned char  rl_drive_c[RAMb];           // ******* RL02 Structure @ RAM/=union ********
       unsigned short rl_drive_i[RAMs];           // Virtual access to 512 cylinders(head 0 and 1)
       unsigned int   rl_drive_l[RAMi];           // 2* 40 sectors = 11520 16 bit * 512 = 5898240/unit
};
//union  rlt RLDRIVE;                             // define a union of type RLDRIVE
union  rlt RLDRIVE __attribute__ ((aligned(4)));  // define a union of type RLDRIVE
union  rlt *u_rl02_drive_ptr;                     // pointer to union
//------------------------------------------------------------------------------------------------------
int fd;                                           // Hold FPGA address
void *virtual_base;                               // Virtual axi-lw addr that maps to physical
void *axi_virtual_base;                           // Virtual axi-master addr that maps to physical
void *PIO_0_addr;                                 // PIO-0 address
void *PIO_1_addr;                                 // PIO-1 address
void *DPR;                                        // Dual Ported Ram address
void *DPR_addr;                                   // Dual Ported Ram address with AXI-Master
//void *UART0;                                    // UART_0 address
//FILE* fp;
//------------------------------------------------------------------------------------------------------
unsigned short int rl_status    = RL02_OK ;
unsigned short int header_index =    3;           // Header index =3
unsigned short int data_start =     10;           // + 7, = +header=3 +PD1=1 +PR2=3
unsigned short int data_CRC =      138;           // + 128
unsigned short int clone_offset =    0;
//
unsigned short int RL_unit  =        0;           // configured  RL unit(s) ( Statisch )
unsigned short int RL_Nr    =        0;           // current used Drive Number
unsigned short int RL_Nr_old    =    0;           // Used Drive Number before
unsigned short int RL_match =        0;           // Match for RL Unit binary notation
unsigned short int RL_match_old =    0;           // Used Match before
int SDRAM                   = 11796480;           // Used bytes in RAM for one RL-unit
unsigned short MAXCYL       =      511;           // cylinder, RL01/Rl02
//
short int mode=0;                                 // System operating mode
//
unsigned char DEBUG=0;                            // DEBUG PURPOSE
unsigned char OFFLINE=0;                          // online/offline mode
unsigned char OFFMODE=0;                          // full/simple offline mode
unsigned char RL=1;                               // 0=RL01 , 1=RL02
unsigned char format=0;                           // Init(format) disk set
unsigned char dl0=0;                              // Unit 0
unsigned char dl1=0;                              // Unit 1
unsigned char dl2=0;                              // Unit 2
unsigned char dl3=0;                              // Unit 3
unsigned char usingdefault=0;                     // using default cartridges SN's
unsigned char noDECfile=0;
//
unsigned char RL_drive_nr_changed=0;              // Flag to indicate a RL-drive UNIT number change was done
//
//unsigned char usingdefault=0;
unsigned char priwhile = 0;
unsigned char secwhile = 0;
//
unsigned short int head=0, Old_head=0;
unsigned short int dl0_head=0, dl0_Old_head=0;
unsigned short int dl1_head=0, dl1_Old_head=0;
unsigned short int dl2_head=0, dl2_Old_head=0;
unsigned short int dl3_head=0, dl3_Old_head=0;
//
int Cylinder_nr=0;                               // Cylinder number , 0 - 255 ( RL02 )
int dl0_cnr=0, dl1_cnr=0, dl2_cnr=0, dl3_cnr=0;
//
int Old_Cyl_nr = 0;                              // Cylinder address SAVE
int dl0_Old_Cyl_nr=0, dl1_Old_Cyl_nr=0, dl2_Old_Cyl_nr=0, dl3_Old_Cyl_nr=0;
//
int Cylinder_nr_diff = 0;                       // Difference to last cylinder_adress
int RAM_cyl_addr;                               // Address @RAM , (Cylinder_nr * CYL_size)
//
int BASE = RL0_base;
int DEST = RL1_base;
int rlBASE;
int RAM_Address = RL0_base;
int Old_RAM_Address = RL0_base;
int unit_base;
//
unsigned int rlname;
//char *myfile1 = "PDP11GY.INF";
char myfile1[40];
char myfile2[80];
char set[20];
char myfile3[80];
char myfile4[80];
//
//
/*******************************************************************************************************/
//
//
void init_HW(void)
{
  //---------------------------------------------------------------------------------------------------
  // === get FPGA addresses ===
  // Open /dev/mem
  if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        printf( "ERROR: could not open \"/dev/mem\"...\n" );
  return; }
  //---------------------------------------------------------------------------------------------------
  // Get virtual addr that maps to physical
  virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );
  if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        close( fd );
  return; }
  axi_virtual_base = mmap( NULL, HW_FPGA_AXI_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, ALT_AXI_FPGASLVS_OFST );
  //----------------------------------------------------------------------------------------------------
  //
  // Get the addresses that maps to the FPGA control 
  PIO_0_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_0_BASE ) 
                                & ( unsigned long)( HW_REGS_MASK ) );
  PIO_1_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_1_BASE ) 
                                & ( unsigned long)( HW_REGS_MASK ) );
  DPR =  virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + DPR_BASE )
                      & ( unsigned long)( HW_REGS_MASK ) ); 
  DPR_addr =   axi_virtual_base + ( ( unsigned long  )( DPR_BASE ));  // This works with DPR !!!
//  UART0 = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UART_0_BASE )
//                      & ( unsigned long)( HW_REGS_MASK ) ); 
  if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        close( fd );
        return; }
  //-----------------------------------------------------------------------------------------------------
  // 
}
//
//
void PRESET_one_SECTOR(void) {
  // initialize data for one sector used for test and reference purpose.
  int i;
  header_index = 3;                                                   // **** Set ****
  data_start = header_index + 7;                                      // **** Set ****
  data_CRC = header_index + 135;                                      // **** Set ****
  unsigned short mysector[]=
  { 0x0000, 0x0000, 0x8000,                                           //  PR1,header_index=3
    0x0000, 0x0000, 0x0000,                                           //  Header
    0x0000,                                                           //  PD1
    0x0000, 0x0000, 0x8000,                                           //  PR2
    0x0000, 0x0000,                                                   //  Data 00-01
    0xFF00, 0xFF00, 0xFF00, 0xFF00, 0xFF00, 0x0000, 0x0000, 0x0000,   //  Data 02-09
    0x3333, 0x3333, 0x3333, 0x3333, 0x3333, 0x0000, 0x0000, 0x5500,   //  Data 10-17
    0x5555, 0x5555, 0x5555, 0x5555, 0x0055, 0x0000, 0x0000, 0x9249,   //  Data 18-25
    0x4924, 0x2492, 0x9249, 0x0024, 0x0000, 0x0000, 0x9123, 0x23DC,   //  Data 26-33
    0xDC91, 0x9123, 0x00DC, 0x0000, 0x0000, 0x8080, 0x8080, 0x8080,   //  Data 34-41
    0x8080, 0x8080, 0x0000, 0x0000, 0xE700, 0xF39C, 0x9CE7, 0xE7F3,   //  Data 42-49
    0xF39C, 0x0000, 0x0000, 0x6300, 0xF18C, 0x8C63, 0x63F1, 0xF18C,   //  Data 50-57
    0x0000, 0x0000, 0x7F00, 0x7F7F, 0x7F7F, 0x7F7F, 0x7F7F, 0x007F,   //  Data 58-65
    0x0000, 0x0000, 0x0D0A, 0x5453, 0x4C45, 0x204C, 0x4944, 0x2052,   //  Data 66-73
    0x4F56, 0x2052, 0x5345, 0x4920, 0x5453, 0x4B20, 0x4952, 0x4745,   //  Data 74-81
    0x5520, 0x444E, 0x4B20, 0x4945, 0x454E, 0x2052, 0x4547, 0x5448,   //  Data 82-89
    0x4820, 0x4E49, 0x0D0A, 0x2020, 0x4D49, 0x4741, 0x4E49, 0x2045,   //  Data 90-97
    0x5449, 0x4920, 0x2053, 0x4157, 0x2052, 0x4E41, 0x2044, 0x4F4E,   //  Data 98-105
    0x4F42, 0x5944, 0x4720, 0x414F, 0x2053, 0x4854, 0x5245, 0x2045,   //  Data 106-113
    0x0A20, 0xFF0D, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF,   //  Data 114-121
    0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x0000,                   //  Data 122-127
    0x6588,                                                           //  Data 128 = CRC
    0x0000,                                                           //  129 = PD2           
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,   //  130-137=Zero
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,   //  138-145=Zero
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000 }; //  146-153=Zero
  //
  //
  for (i = 0; i < 256; i++ ){ SECTOR.rl02i[i] = 0x0000; }             // clear buffer
  for (i = 0; i < 150; i++ ){ SECTOR.rl02i[i] = mysector[i]; }        // Load buffer
  //make_data_CRC();
  //printf("\r\n CRC=%04X \n\r", SECTOR.rl02i[data_CRC]);             // must be 0X6588
    SECTOR.rl02l[100]=0x2E575757; 
    SECTOR.rl02l[101]=0x31504450;  
    SECTOR.rl02l[102]=0x2E594731;  
    SECTOR.rl02l[103]=0x204D4F43; 
    SECTOR.rl02l[127]=0x45444E45; // "ENDE" = Indicator
}
//
//
void startup_leds(void)
{
int loop_count;
int led_direction;
int led_mask;
loop_count = 0;
led_mask = 0x01;
led_direction = 0; // 0: left to right direction
    //
    while(loop_count < 3 )  {
      *(uint32_t *)PIO_0_addr = led_mask;
      usleep( 20*1000 );
      if (led_direction == 0){
            led_mask <<= 1;
            if (led_mask == (0x01 << (PIO_0_DATA_WIDTH-1)))
                 led_direction = 1;
        }else{
            led_mask >>= 1;
            if (led_mask == 0x01){ 
                led_direction = 0;
                loop_count++;
            }
        }        
    }
}
//
//
void print_sector(void){
 int j;
 printf("\n\r------------------------------------------------------------------\n\r");
 for (j = 0; j < 256; j++ ) {
    printf("%c",SECTOR.rl02c[j]);
 }
 printf("\n\r------------------------------------------------------------------\n\r");
}
//
//
void print_binary_16bit_LSB( unsigned short ibit16){
// Representation: LSB on right site ( PDP-11 like)
 int i;
  for (i = 0; i < 16; i++ ){
       if(0x8000 & ibit16 ) {               // Test Bit 15
          printf("1");
       }else {
          printf("0");
       }
       if((i==3) | (i==7) | (i==11)) {
          printf(" "); 
       }  
   ibit16 = ibit16 << 1;
  }
}
//
//
//- calcCRC16r ------------------------------------------------------
unsigned short int calcCRC16r(unsigned short int crc, unsigned short int c, unsigned short int mask)
//
// Note: This smart C-Code was not written by myself.
// Reference: http://www.mikrocontroller.net/topic/12177#2274632
{
  unsigned char i;
  for(i=0;i<8;i++)
  {
    if((crc ^ c) & 1) { crc=(crc>>1)^mask; }
    //if((crc = crc  ^ c) & 1) { crc=(crc>>1)^mask; }
    else crc>>=1;
    c>>=1;
  }
  return (crc);
}
//
//
void make_header_CRC(void){
  unsigned short int DEVICE_CRC16 = 0;
  // Header - Word 1 of 3  ( data )
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[header_index*2],0xA001);   //HSB
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[header_index*2+1],0xA001); //LSB
  // Header - Word 2 of 3  ( always 0 )
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[header_index*2+2],0xA001); //HSB
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[header_index*2+3],0xA001); //LSB
  // Header - Word 3 of 3  -> Header-CRC
  SECTOR.rl02i[header_index+2]=DEVICE_CRC16;
}
//
//
void make_data_CRC(void){
  unsigned short int i, MSB, LSB;
  unsigned short int DEVICE_CRC16;
  //
  DEVICE_CRC16 = 0;                             // preset Data-CRC
  //
  for (i = data_start; i < data_CRC; i++ ){
    MSB = i<<1;      // = i*2
    LSB = MSB + 1;
    DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[MSB],0xA001);
    DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[LSB],0xA001);
  }
  SECTOR.rl02i[data_CRC] = DEVICE_CRC16;       // SET DATA-CRC
}
//
//
void make_bad_sector_file(void) {
// reconstruct error free RL Cartridge (EF)
   unsigned short int j = data_start, i=0;
   //
   SECTOR.rl02i[j]   = RL0SN_1;                          // 0,1 = Cartridge SN
   SECTOR.rl02i[j+1] = RL0SN_2;                          // 0,1 = Cartridge SN
   SECTOR.rl02i[j+2] = 0x0000;                           // 2 = unused
   SECTOR.rl02i[j+3] = 0x0000;                           // 3 = Written with Zeros for Data Cartridge
   SECTOR.rl02i[j+4] = 0xFFFF;                           // 4 = Ones until End of sector = Error free
   for (i = j+4; i < 256; i++ ){
      if( i > data_start +128) {
         SECTOR.rl02i[i] = 0x000;
      } else {
          SECTOR.rl02i[i] = 0xFFFF;
      }
   }
   make_data_CRC();
}
//
//
void SN_default(void) {
// set default Cartridge Serial numbers for DL0 to DL1
    int point;
    point = (SEC_size_i*80)*MAXCYL + data_start;
    //
    RLDRIVE.rl_drive_i[point] = RL0SN_1;
    RLDRIVE.rl_drive_i[point+1] = RL0SN_2;
    RLDRIVE.rl_drive_i[point+RL1_base] = RL1SN_1;
    RLDRIVE.rl_drive_i[point+RL1_base+1] = RL1SN_2;
    RLDRIVE.rl_drive_i[point+RL2_base] = RL2SN_1;
    RLDRIVE.rl_drive_i[point+RL2_base+1] = RL2SN_2;
    RLDRIVE.rl_drive_i[point+RL3_base] = RL3SN_1;
    RLDRIVE.rl_drive_i[point+RL3_base+1] = RL3SN_2;
    //
}
//
//
void SN_write(void){
// Write serial-numbers to SD-Card, in file SNx.txt
//
    FILE    *fptr;
    //
    int point;
    point = (SEC_size_i*80)*MAXCYL + data_start;
    //
    fptr = fopen(myfile3, "w");
    if(fptr == NULL) {
      printf ("\n\r\x07 ERROR No SD-Card write access! Restart system \n\r");
      while(1); }
   //
   fprintf(fptr, "%X,%X",RLDRIVE.rl_drive_i[point],RLDRIVE.rl_drive_i[point+1]);
   fprintf(fptr, "\r\n%X,%X",RLDRIVE.rl_drive_i[RL1_base+point],RLDRIVE.rl_drive_i[RL1_base+point+1]);
   fprintf(fptr, "\r\n%X,%X",RLDRIVE.rl_drive_i[RL2_base+point],RLDRIVE.rl_drive_i[RL2_base+point+1]);
   fprintf(fptr, "\r\n%X,%X",RLDRIVE.rl_drive_i[RL3_base+point],RLDRIVE.rl_drive_i[RL3_base+point+1]);
   fclose(fptr);
}
//
//

void SN_read(void){
// Read and Set serial-numbers ( HEX ) from SD-CARD, file SNx.txt
// Note !!! DATA CRC has to be rebuild !!!!!
//
    FILE    *fptr;
    int point;
    point = (SEC_size_i*80)*MAXCYL + data_start;
    char EineZeile[100];
    char * pch;
    //
    if(OFFLINE == FALSE) {
        fptr = fopen(myfile3, "r");
        if(fptr == NULL) {
           //printf ("\n\n\r\x07 ERROR opening SN file: %s , using defaults \n\r", myfile3);
           printf ("\n\n\r\x07 SN file: %s not available, leave the set values \n\r", myfile3);
           usingdefault=1;
        } else {
           usingdefault=0;
           //
           fgets(EineZeile, sizeof(EineZeile), fptr);                   // read one line
           //printf ("\r\nDL0: %s", EineZeile);
           pch = strtok (EineZeile,",");                                // split string
           //RLDRIVE.rl_drive_i[point] = atoi(pch);                     // mit atoi gehts nicht :-(
           RLDRIVE.rl_drive_i[point] = strtol(pch, 0, 16);
           pch = strtok (NULL, ",");                                    // split string
           RLDRIVE.rl_drive_i[point+1] = strtol(pch, 0, 16);
           //
           rlBASE=RL0_base;
           SN_rebuild_CRC();
           //
           fgets(EineZeile, sizeof(EineZeile), fptr);                   // read one line
           //printf ("\r\nDL1: %s", EineZeile);
           pch = strtok (EineZeile,",");                                // split string
           RLDRIVE.rl_drive_i[RL1_base+point] = strtol(pch, 0, 16);
           pch = strtok (NULL, ",");                                    // split string
           RLDRIVE.rl_drive_i[RL1_base+point+1] = strtol(pch, 0, 16);
           //
           rlBASE=RL1_base;
           SN_rebuild_CRC();
           //
           fgets(EineZeile, sizeof(EineZeile), fptr);                   // read one line
           //printf ("\r\nDL2: %s", EineZeile);
           pch = strtok (EineZeile,",");                                // split string
           RLDRIVE.rl_drive_i[RL2_base+point] = strtol(pch, 0, 16);
           pch = strtok (NULL, ",");                                    // split string
           RLDRIVE.rl_drive_i[RL2_base+point+1] = strtol(pch, 0, 16);
           //
           rlBASE=RL2_base;
           SN_rebuild_CRC();
           //
           fgets(EineZeile, sizeof(EineZeile), fptr);                    // read one line
           //printf ("\r\nDL3: %s", EineZeile);
           pch = strtok (EineZeile,",");                                // split string
           RLDRIVE.rl_drive_i[RL3_base+point] = strtol(pch, 0, 16);
           pch = strtok (NULL, ",");                                    // split string
           RLDRIVE.rl_drive_i[RL3_base+point+1] = strtol(pch, 0, 16);
           //
           rlBASE=RL3_base;
           SN_rebuild_CRC();
           //
           fclose(fptr);
          //
         //
        }
    }
}
//
void SN_rebuild_CRC(void){
    int point, i;
    point = (SEC_size_i*80)*MAXCYL + rlBASE;
    //
    for(i = 0; i< SEC_size_i; i++) {
        SECTOR.rl02i[i] = RLDRIVE.rl_drive_i[point+i];
    }
    make_data_CRC();
    //
    for(i = 0; i< SEC_size_i; i++) {
        RLDRIVE.rl_drive_i[point+i] = SECTOR.rl02i[i];
    }
}
//%08X
void SN_print(void){
    int point;
    point = (SEC_size_i*80)*MAXCYL + data_start;
    //
    if(OFFLINE==FALSE){
        printf("\r\n\n  RL cartridges Serial-Numbers(HEX)");
        if(usingdefault == FALSE) {
            printf(", located in file %s", myfile3);
        }
        //
        if(dl0 == FALSE){ printf("\r\n      DL0: not in use"); } else {
            printf("\r\n      DL0: %04X,%04X",RLDRIVE.rl_drive_i[point],RLDRIVE.rl_drive_i[point+1]);}
        if(dl1 == FALSE){ printf("\r\n      DL1: not in use"); } else {
            printf("\r\n      DL1: %04X,%04X",RLDRIVE.rl_drive_i[RL1_base+point],RLDRIVE.rl_drive_i[RL1_base+point+1]);}
        if(dl2 == FALSE){ printf("\r\n      DL2: not in use"); } else {
            printf("\r\n      DL2: %04X,%04X",RLDRIVE.rl_drive_i[RL2_base+point],RLDRIVE.rl_drive_i[RL2_base+point+1]);}
        if(dl3 == FALSE){ printf("\r\n      DL3: not in use"); } else {
            printf("\r\n      DL3: %04X,%04X",RLDRIVE.rl_drive_i[RL3_base+point],RLDRIVE.rl_drive_i[RL3_base+point+1]);}
        printf("\r\n");
    }
}
//
//
void make_offline_track0(void) {
    // construct sector data  @ cylinder 0+1 and bad sector file into memory
    unsigned short int RL_sector,  RL_cylinder=0, i, temp;
    int nr = 0;
    printf ("\n\r              ********* OFFLINE MODE *********");
    printf ("\n\r              *  Construct cylinder 0-31 and *");
    printf ("\n\r              *     bad sector file only     *");
    printf ("\n\r              ********************************\n\r");
    //
    for (RL_cylinder = 0; RL_cylinder < 31; RL_cylinder++ ) {
    //
        for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {  // construct 40 sectors @ head 0
            temp = 0;
            temp = RL_cylinder<<7;                            // Set RL01-Cylinder address
            temp = temp | RL_sector;                          // Set RL01-Sector
            temp = temp &~0x40;                               // Clear = select head-0
            SECTOR.rl02i[header_index] = temp;                // >> SET <<
            make_header_CRC();                                // build header CRC
            //if(RL_sector == 0){                             // >>>>> SET:  make sector 0 <<<<<<
            if((RL_sector == 0) & (RL_cylinder == 0)){        // >>>>> SET:  make sector 0 <<<<<<
                make_bootsector();
            }
            for(i = 0; i< SEC_size_i; i++) {
                RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
            }
            if((RL_sector == 0) & (RL_cylinder == 0)){        // >>>> RESET: make sector 0 <<<<<<
                PRESET_one_SECTOR(); 
            }
            nr = nr + SEC_size_i;
        }
        //
        //
        for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {     // construct 40 sectors @ head 1
            temp = 0;
            temp = RL_cylinder<<7;                             // Set RL-Cylinder address
            temp = temp | RL_sector;                           // Set RL-Sector
            temp = temp | 0x40;                                // Set = select head-1
            SECTOR.rl02i[header_index] = temp;                 // >> SET <<
            make_header_CRC();                                 // build header CRC
            for(i = 0; i< SEC_size_i; i++) {
                RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];     // Copy track into RAM
            }
            nr = nr + SEC_size_i;
        }
    }
   //
   make_bad_sector_file();
   RL_cylinder = MAXCYL;
   nr = (SEC_size_i*80)*MAXCYL;                           // point to last,= bad sector Cylinder
   //
   //
   for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {    // construct 40 sectors @ head 0
        temp = 0;
        temp = RL_cylinder<<7;                            // Set RL01-Cylinder address
        temp = temp | RL_sector;                          // Set RL01-Sector
        temp = temp &~0x40;                               // Clear = select head-0
        SECTOR.rl02i[header_index] = temp;                // >> SET <<
        make_header_CRC();                                // build header CRC
        for(i = 0; i< SEC_size_i; i++) {
            RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
        }
        nr = nr + SEC_size_i;
    }
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {  // construct 40 sectors @ head 1
        temp = 0;
        temp = RL_cylinder<<7;                            // Set RL01-Cylinder address
        temp = temp | RL_sector;                          // Set RL01-Sector
        temp = temp | 0x40;                               // Set = select head-1
        SECTOR.rl02i[header_index] = temp;                // >> SET <<
        make_header_CRC();                                // build header CRC
        for(i = 0; i< SEC_size_i; i++) {
            RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
        }
        nr = nr + SEC_size_i;
    }
}
//
//
void make_rl_structure_in_ram(void) {
// +
// construct full RL01/RL02 image in Memory ( union = SD RAM )
// the idea behind this routine is to dump the memory contents in pieces of 512 byte
// to the SD-Card after constructing the RL01 image in Memory.
// -
unsigned short int RL_sector, RL_cylinder, i;
//unsigned short int RL_sector, RL_cylinder, dot=0, led0=0x0001, led1=0x8000, i;
short int temp;
int nr=0;
 //printf("\n\r MAXCYL:   %d \r\n", MAXCYL);
 for (RL_cylinder = 0; RL_cylinder < MAXCYL; RL_cylinder++ ) {
  //
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) { // construct 40 sectors @ head 0
        temp = 0;
        temp = RL_cylinder<<7;                            // Set RL-Cylinder address
        temp = temp | RL_sector;                          // Set RL-Sector
        temp = temp &~0x40;                               // Clear = select head-0
        SECTOR.rl02i[header_index] = temp;                // >> SET <<
        make_header_CRC();                                // build header CRC
        //if(RL_sector == 0){                             // >>>>> SET:  make sector 0 <<<<<<
        if((RL_sector == 0) & (RL_cylinder == 0)){        // >>>>> SET:  make sector 0 <<<<<<
           make_bootsector();}
        for(i = 0; i< SEC_size_i; i++) {
            RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
        }
        if((RL_sector == 0) & (RL_cylinder == 0)){        // >>>> RESET: make sector 0 <<<<<<
            PRESET_one_SECTOR(); 
        }
        nr = nr + SEC_size_i;
    }
    //
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {  // construct 40 sectors @ head 1
        temp = 0;
        temp = RL_cylinder<<7;                             // Set RL-Cylinder address
        temp = temp | RL_sector;                           // Set RL-Sector
        temp = temp | 0x40;                                // Set = select head-1
        SECTOR.rl02i[header_index] = temp;                 // >> SET <<
        make_header_CRC();                                 // build header CRC
        for(i = 0; i< SEC_size_i; i++) {
            RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];     // Copy track into RAM
        }
        nr = nr + SEC_size_i;
        }
    }
   // RT-11 command to get contents of RL01 Bad Sector file: dump/term/only:23730 dl0:
   //
   make_bad_sector_file();
   //
   RL_cylinder = MAXCYL;                                  // point to last cylinder
   //
   //
   for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {    // construct 40 sectors @ head 0
        temp = 0;
        temp = RL_cylinder<<7;                            // Set RL01-Cylinder address
        temp = temp | RL_sector;                          // Set RL01-Sector
        temp = temp &~0x40;                               // Clear = select head-0
        SECTOR.rl02i[header_index] = temp;                // >> SET <<
        make_header_CRC();                                // build header CRC
        for(i = 0; i< SEC_size_i; i++) {
            RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
        }
        nr = nr + SEC_size_i;
    }
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {  // construct 40 sectors @ head 1
        temp = 0;
        temp = RL_cylinder<<7;                            // Set RL-Cylinder address
        temp = temp | RL_sector;                          // Set RL-Sector
        temp = temp | 0x40;                               // Set = select head-1
        SECTOR.rl02i[header_index] = temp;                // >> SET <<
        make_header_CRC();                                // build header CRC
        for(i = 0; i< SEC_size_i; i++) {
            RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
        }
        nr = nr + SEC_size_i;
    }
 }
//
//
void make_bootsector(void) {
 short int i;
 unsigned short bootsector[]=
 { 0x00A0, 0x0005, 0x0104, 0x0000, 0x0000, 0x4310, 0x9C10, 0x0100,       // * ..........C....*
   0x0837, 0x0024, 0x000D, 0x0000, 0x0A00, 0x423F, 0x4F4F, 0x2D54,       // *7.$.......?BOOT-*
   0x2D55, 0x6F4E, 0x6220, 0x6F6F, 0x2074, 0x6E6F, 0x7620, 0x6C6F,       // *U-No boot on vol*
   0x6D75, 0x0D65, 0x0A0A, 0x0080, 0x8BDF, 0xFF74, 0x80FD, 0x941F,       // *ume....._.t.}...*
   0xFF76, 0x80FA, 0x01FF, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000 };     // *v.z.............*
   //
    for (i = data_start; i < 256; i++ ) {
        SECTOR.rl02i[i] = 0x0000;                                             // clear data area
    }
    for (i = 0; i < 40; i++){
        SECTOR.rl02i[i+data_start] = bootsector[i];                           // init Sector
    }
  make_data_CRC();
}
//
//
void WRITE_drive_to_FPGA(int point_to_track){
  //
  // FPGA Dual-Ported-RAM size: 40 x SEC_size 16bit words = 5760 16bit words/track
  // This routine writes one sector from union RLDRIVE.rl_drive_i to FPGA/DP-RAM
  //                               ##################
  //                               ### RAM-->FPGA ###
  //                               ##################
  //
  //if((DEBUG == TRUE) & (OFFLINE == TRUE)){
  //    printf("\n\r>>> RAM -> FPGA/DPR @Base: %d  = Track-Address: %d \n\r", BASE, point_to_track); }
  //
  memcpy((void *)(DPR_addr), &RLDRIVE.rl_drive_i[point_to_track], SEC_size_c * 40);
  //
}
//
//
void READ_drive_from_FPGA(int point_to_track){
    //
    // FPGA Dual-Ported-RAM size: 40 x SEC_size 16bit words = 5760 16bit words/track
    // This routine reads one sector from FPGA/DP-RAM into union RLDRIVE.rl_drive_i
    //                               ##################
    //                               ### FPGA-->RAM ###
    //                               ##################
    //
    //if((DEBUG == TRUE) & (OFFLINE == TRUE)){
    //   printf("\n\r<<< RAM <- FPGA/DPR @Base: %d  = Track-Address: %d \n\r", BASE, point_to_track); }
    //
    //
    memcpy(&RLDRIVE.rl_drive_i[point_to_track], (void *)(DPR_addr), SEC_size_c * 40);
    find_PR1(point_to_track);
    //
    //-----------------------------------------------------------------------+
    // This error handling is no longer necessary.  The cause of the problem 
    // was related to the firmware and is fixed with version 2.2.
    int DATAOFFS = data_start*2 , point = point_to_track*2 ,i,k ;
    for(i = 0 ; i < 40; i++) {
        if (RLDRIVE.rl_drive_c[point + DATAOFFS - 1] != 0x80)  {
            if (RLDRIVE.rl_drive_c[point + DATAOFFS - 1] & 0x40)  {
                for (k = point+DATAOFFS + 258; k >= point+DATAOFFS - 1; k--) {
                    RLDRIVE.rl_drive_c[k] = (RLDRIVE.rl_drive_c[k] << 1) | (RLDRIVE.rl_drive_c[k - 1] >> 7);
                }
            }else{
               printf("\n\r\x07 Non-correctable bit-shift error @PR2: %04X ",RLDRIVE.rl_drive_c[point + DATAOFFS - 1] );
            }
        }
        point = point + SEC_size_c;
    }   
    //-----------------------------------------------------------------------+
    //
}
//
//
void make_myfile_on_SD_Card(void){
  FILE    *fptr;
  int ch;
  //
  fptr = fopen(myfile1, "w");
  if(fptr == NULL) {
    printf ("\n\r\x07 ERROR open/write file %s \n\r", myfile1);
    //IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
    while(1); }
  fprintf(fptr,"       SOC/HPC based V2.8E RL01/RL02 disk emulator \r\n");
  fprintf(fptr,"          developed with Quartus Version 16.1     \r\n");
  fprintf(fptr,"         Copyright (C) by Reinhard Heuberger\r\n");
  fprintf(fptr,"          www.pdp11gy.com  info@pdp11gy.com\r\n");
  fclose(fptr);
  //
  fptr = fopen(myfile4, "w");
  if(fptr == NULL) {
     printf ("\n\r\x07 ERROR open/write file %s \n\r", myfile4);
     //IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
     while(1); }
    fprintf(fptr,"                SOC/HPC based V2.8E RL01/RL02 disk emulator  \r\n");
    fprintf(fptr,"                   developed with Quartus Version 16.1 \r\n ");
    fprintf(fptr,"                 (C) www.pdp11gy.com  info@pdp11gy.com\r\n");
    fprintf(fptr,"                           info-file %s  \r\n", myfile4);
    fprintf(fptr,"           <Edit the file %s to change the info-message>", myfile4);
    fclose(fptr);
    //
    fptr = fopen(myfile1, "r");
    if(fptr == NULL) {
       printf ("\n\r\x07 ERROR reading file %s \n\r", myfile1);
       //IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
      while(1); }
      //
   while ((ch = fgetc(fptr)) != EOF)
    {
      printf("%c", ch);
    }
  fclose(fptr);  
}
//
//
void send_drive_info( unsigned short infodrive){
  //IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, infodrive);                 // Preset PIO
  *(uint32_t *)PIO_0_addr = infodrive;
}
//
//
void acknowledge(void){
  // Terminate Seek-cycle,  sending a acknowledge pulse  @ O_ctrl[2]
  *(uint32_t *)PIO_1_addr = (mode=mode|0x0004);
  usleep( 100 );
  *(uint32_t *)PIO_1_addr = (mode=mode&~0x0004);
}
//
//
void show_all_header_in_track(int adresse) {
    int ix,jx;
    jx = adresse;
    printf("\n\roffset  [2] ,   [3] ,   [4] ,   [5] ,   [6] ,   [7] ,   [8],    [9]");
    for (ix = 0; ix < 40; ix++ ) {
        printf("\n\r[%d] =  %04X ,  %04X ,  %04X ,  %04X ,  %04X , %04X ,   %04X ,  %04X", ix, 
        RLDRIVE.rl_drive_i[jx+2],RLDRIVE.rl_drive_i[jx+3], RLDRIVE.rl_drive_i[jx+4], 
        RLDRIVE.rl_drive_i[jx+5],RLDRIVE.rl_drive_i[jx+6],
        RLDRIVE.rl_drive_i[jx+7],RLDRIVE.rl_drive_i[jx+8],RLDRIVE.rl_drive_i[jx+9]);
        //
        jx=jx+SEC_size_i;
    }   
    printf("\r\n\n");
    fflush(stdout);
}
//
//
void find_PR1(int point_to_track) {
/*
    In Zeiten von Pandemie und Lock-Down Nr. 2. 
*/
    unsigned short int temp, found, RL_sector;
    int RAMadress, RAM, base;
    RAM =       point_to_track;
    RAMadress = point_to_track;
    base =      point_to_track;
    for (RL_sector = 0;  RL_sector <=39 ; RL_sector++) {
        found = 0;
        RAM   = base;
        do {
            RAM   = RAM +1;
            found = found +1;
            temp  = RLDRIVE.rl_drive_i[RAM];
        }while((temp != 0x8000) & ( found < 20));
        //
        //printf("\n\r PR1 found @ %d  ,sector: %d", found, RL_sector);  // schould be @ 2
        clone_offset = found - 2;                                        // calculate current clone_offset
        if(found > 8) {
            printf("\n\r\n       ------- Fatal Header ERROR ------ ");
            printf("\n\r\n            cylinder:%d , sector: %d ", (RAMadress/CYL_size),RL_sector);
            show_all_header_in_track(RAMadress);
            fflush(stdout);
            exit(0);
        }
        if(found > 2) {
            squeeze_track(base); 
        }else{
            clone_offset = 0;
        }
        base = base + SEC_size_i;                                      // next sector 
    }
    clone_offset = 0;
    //
    header_index = 3 + clone_offset;                    // add clone_offset       
    data_start =  10 + clone_offset;                    //  because in clone mode
    data_CRC =   138 + clone_offset;                    //   MFM start is 6 bytes earlier 
}
//
//
void squeeze_track(int point_to_track) {
    int base, to , from, size ;
    base = point_to_track;
    to   = base ;
    from = base + clone_offset;
    size = (SEC_size_i-clone_offset)*2;
    memmove(&RLDRIVE.rl_drive_i[to],  &RLDRIVE.rl_drive_i[from], size );
    clone_offset = 0;
}
//
//
void WRITE_to_SD_Card(void){
  //
  // RL01: 5,62 MB ( 5.898.752 Bytes)
  // RL02: 11,2 MB (11.796.992 Bytes)
  //
  //FILE    *fptr;
  //int loops = SDRAM/20480, i=0, j=0, 
  int k=0;
  unsigned char conf=0;
  //
  //
  for(k=0; k<4; k++) {
        switch(k) {
        case 0:
            if((dl0 == TRUE) | (format == TRUE)){ 
               conf=1;
               strcat( myfile2, "_0" );strcat( myfile2,set );
            } else { 
               conf=0;
            }
            RL_Nr = 0;
            unit_base=RL0_base; break;
        case 1:
            if((dl1 == TRUE) | (format == TRUE)){ 
               conf=1;
               strcat( myfile2, "_1" );strcat( myfile2,set );
            } else { 
               conf=0;
            }
            RL_Nr = 1;
            unit_base=RL1_base; break;
        case 2:
            if((dl2 == TRUE) | (format == TRUE)){ 
               conf=1;
               strcat( myfile2, "_2" );strcat( myfile2,set );
            } else { 
               conf=0;
            }
            RL_Nr = 2;
            unit_base=RL2_base; break;
        case 3:
            if((dl3 == TRUE) | (format == TRUE)){
               conf=1;
               strcat( myfile2, "_3" );strcat( myfile2,set );              
            } else { 
               conf=0;
            }
            RL_Nr = 3;
            unit_base=RL3_base; break;
        }
        if(conf == TRUE){
            printf ("\n\r+----------------------------------------------------------------------+");
            printf ("\n\r|    Unit number: %d  ", RL_Nr);
            printf (">  Write to file %s ", myfile2);
            //-------------
            write_DEC();
            //-------------
            myfile2[10]='S';
            myfile2[11]='K';
            //-------------
            printf ("and %s    |\n\r", myfile2);
            write_DSK();
            printf ("+----------------------------------------------------------------------+\r\n");
            //-------------
            if(RL == TRUE ){
                strcpy( myfile2, "RL02" );
            }else{
                strcpy( myfile2, "RL01" );
            }
        } else {
            printf ("\n\r    Unit number: %d  not configured, will be skipped \n\r", RL_Nr);
        }
    }
}
//
//
void write_DEC(void) {
    //
    // Write RL memory-image to the .DEC file
    //
    FILE    *fptr;
    int loops = SDRAM/20480, i=0, j=0;
    //unsigned short dot=0, led=0x8000;
    //
    fptr = fopen(myfile2, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile2);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    i=unit_base *2;                                                              // !!! *2, da byte
    for(j=0; j<loops; j++) {
        fwrite((void*)&RLDRIVE.rl_drive_c[i], 1 , 20480, fptr );    
        i=i+20480;                                                         //In Steps of 20480 byte
    }       
    fwrite((void*)&SECTOR.rl02c[0], 1, 512, fptr );
    //
    fclose(fptr);   
}
//
//
void write_DSK(void) {
    //
    // Write RL memory image to the .DSK file
    //
    FILE    *fptr = 0;
    byte sectorbuf[288];
    int DATAOFFS = data_start*2;
    int loops = SDRAM/288, i=0, j=0, k=0, l=0;
    //
    fptr = fopen(myfile2, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile2);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    i=unit_base *2; 
    for(j=0; j<loops; j++) {
        //
        for(l = 0; l< SEC_size_c; l++) {                           // copy
            sectorbuf[l] = RLDRIVE.rl_drive_c[i+l];                // sector
        }
        if (sectorbuf[DATAOFFS - 1] & 0x40)  {                     // Daten um 1 Bit verschieben
            for (k = DATAOFFS + 256; k >= DATAOFFS - 1; k--) {
                sectorbuf[k] = (sectorbuf[k] << 1) | (sectorbuf[k - 1] >> 7);
            }
        }
        fwrite(sectorbuf + DATAOFFS, 1, 256, fptr);
        i=i+288;        
    }
    fclose(fptr);       
}
//
//
void read_infofile_from_SD_Card(void){
    FILE    *fptr;
    char EineZeile[100];
    fptr = fopen(myfile4, "r");
        if(fptr == NULL) {
           printf ("n\r\x07     ERROR opening info-file: %s\n\r",myfile4);
        } else {
            while( !feof( fptr ) ) {
              fgets(EineZeile, sizeof(EineZeile), fptr);  // read EineZeile
              printf ("%s", EineZeile);
            }
        }
    fclose(fptr);
}
//
//
void check_ID(void){    
    FILE *fp;
    printf("\n\r *******************************************************************\n\r");
    fp = fopen(myfile1,"r");
        if(fp == NULL) {
           printf ("\n\r\x07    ID-File %s is not available !.. using defaults\n\r", myfile1);
        }else{
           read_infofile_from_SD_Card();
        }
    printf("\n\r *******************************************************************\n\r");
    fflush(stdout);
}
//
//
void READ_from_SD_Card(void){
    //
    // RL01: 5,62 MB ( 5.898.752 Bytes)
    // RL02: 11,2 MB (11.796.992 Bytes)
    //
    int k=0;
    unsigned char conf=0;
    // Preset Memory in Case of reading .DSK files
    BASE = RL0_base;
    make_rl_structure_in_ram();
    memcpy(&RLDRIVE.rl_drive_i[RL1_base], &RLDRIVE.rl_drive_i[BASE], SDRAM );
    memcpy(&RLDRIVE.rl_drive_i[RL2_base], &RLDRIVE.rl_drive_i[BASE], SDRAM );
    memcpy(&RLDRIVE.rl_drive_i[RL3_base], &RLDRIVE.rl_drive_i[BASE], SDRAM );
    //
    fflush(stdout);
    for(k=0; k<4; k++) {
        switch(k) {
        case 0:
            if(dl0 == TRUE){ 
               conf=1;
               strcat( myfile2, "_0" );strcat( myfile2,set );
            }else{ 
               conf=0;
            }
            RL_Nr = 0;
            unit_base=RL0_base; break;
        case 1:
            if(dl1 == TRUE){ 
               conf=1; 
               strcat( myfile2, "_1" );strcat( myfile2,set );
            }else{ 
               conf=0;
            }
            RL_Nr = 1;
            unit_base=RL1_base;break;
        case 2:
            if(dl2 == TRUE){ 
               conf=1;
               strcat( myfile2, "_2" );strcat( myfile2,set );
            }else{ 
               conf=0;
            }
            RL_Nr = 2;
            unit_base=RL2_base; break;
        case 3:
            if(dl3 == TRUE){
               conf=1;
               strcat( myfile2, "_3" );strcat( myfile2,set );              
            }else{ 
               conf=0;
            }
            RL_Nr = 3;
            unit_base=RL3_base; break;
        }
        if(conf == TRUE){
            printf ("\n\r+............................................................................+");
            printf ("\n\r|   Unit number: %d ", RL_Nr);
            printf ("> file %s ", myfile2);
            fflush(stdout);
            //-------------
            read_DEC();
            if(noDECfile == TRUE) {
               //-------------
               myfile2[10]='S';
               myfile2[11]='K';
               //-------------
               printf (" not found, using file %s   |\n\r", myfile2);
               read_DSK();
            } else {
                printf(" used                                 |\r\n");
            }
            printf ("+............................................................................+\n\r");
            //-------------
            if(RL == TRUE ){
                strcpy( myfile2, "RL02" );
            }else{
                strcpy( myfile2, "RL01" );
            }
        }else{
            printf ("\n\r    Unit number: %d  = Not configured \n\r", RL_Nr);
        }
    }
}
//
//
void read_DEC(void) {
    // Read .DEC file 
    FILE    *fptr;
    int loops=SDRAM/20480, i=0, j=0;
    //
    fflush(stdout);
    fptr = fopen(myfile2, "rb");
    if(fptr == NULL) {
        noDECfile = 1;
    } else {
        noDECfile = 0;
        i=unit_base *2;                                                             // !!! *2, da byte
        for(j=0; j<loops; j++) {
            fread((void*)&RLDRIVE.rl_drive_c[i], 1 , 20480, fptr );
            i=i+20480;
        }
        fread((void*)&SECTOR.rl02c[0], 1, 512, fptr );
        fclose(fptr);
    }
}
//
//
void read_DSK(void) {
    // Read .DSK file
    FILE    *infile = 0;
    byte sectorbuf[256];
    int loops = SDRAM/288, i=0, j=0, k=0, m=0;
    infile = fopen(myfile2, "rb");
    if(infile == NULL) {
        printf ("\n\n\n\r\x07 ERROR open/read image .DSK file %s \n\r", myfile2);
        printf ("FIX THIS PROBLEM AND RESTART");
        fflush(stdout);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    i=unit_base;
    for(j=0; j<loops; j++) {                  
        fread(sectorbuf , 1, 256, infile);                           // read one sector
        for(m=0; m<256; m++) {
            SECTOR.rl02c[m + 20] = sectorbuf[m];                     // Copy received sector-buffer to sector
        }
        make_data_CRC();                                             // make Data CRC
        //
        for(k = data_start; k <= data_CRC; k++) {       
            RLDRIVE.rl_drive_i[i+k] = SECTOR.rl02i[k];               // copy sector to RAM(union)
        }
        /*
        // For debug purpose: Print " PR0, first-data, DATA-CRC " from the first 5 sectors
        if( i <= unit_base + SEC_size_i*5 ) {
            printf("\r\n PR2: %X  1st-data %X CRC: %X", RLDRIVE.rl_drive_i[i+data_start-1], 
                     RLDRIVE.rl_drive_i[i+data_start],RLDRIVE.rl_drive_i[i+data_CRC]);
        }
        */
        i=i+SEC_size_i;
    }
    fclose(infile);
    PRESET_one_SECTOR();
}
//
//
void RAM_align(void) {
    switch(RL_Nr_old){
      //--------------------------------------------------------------
      case 0: {                                         // from Unit 0
            dl0_head = head;                            //
            dl0_Old_head = Old_head;                    ///
            dl0_cnr = Cylinder_nr=0;                    ////
            dl0_Old_Cyl_nr = Old_Cyl_nr;                ///// save dl0
            switch(RL_Nr){                              // ***
            case 1:                                     //  to Unit 1
                head = dl1_head;
                Old_head = dl1_Old_head;
                Cylinder_nr = dl1_cnr;
                Old_Cyl_nr = dl1_Old_Cyl_nr;
                BASE = RL1_base;break;
            case 2:                                     //  to Unit 2
                head = dl2_head;
                Old_head = dl2_Old_head;
                Cylinder_nr = dl2_cnr;
                Old_Cyl_nr = dl2_Old_Cyl_nr;
                BASE = RL2_base;break;
            case 3:                                     //  to Unit 3
                head = dl1_head;
                Old_head = dl1_Old_head;
                Cylinder_nr = dl3_cnr;
                Old_Cyl_nr = dl1_Old_Cyl_nr;
                BASE = RL3_base;break;
          }
        }break;
       //---------------------------------------------------------
       case 1: {                                        // from unit 1
            dl1_head = head;                            //
            dl1_Old_head = Old_head;                    ///
            dl1_cnr = Cylinder_nr;                      ////
            dl1_Old_Cyl_nr = Old_Cyl_nr;                ///// save dl1
            switch(RL_Nr) {                             // ***
            case 0:                                     //  to Unit 0
                head = dl0_head;
                Old_head = dl0_Old_head;
                Cylinder_nr = dl0_cnr;
                Old_Cyl_nr = dl0_Old_Cyl_nr;
                BASE = RL0_base;break;
            case 2:                                     //  to Unit 2
                head = dl2_head;
                Old_head = dl2_Old_head;
                Cylinder_nr = dl2_cnr;
                Old_Cyl_nr = dl2_Old_Cyl_nr;
                BASE = RL2_base;break;
            case 3:                                     //  to Unit 3
                head = dl1_head;
                Old_head = dl1_Old_head;
                Cylinder_nr = dl3_cnr;
                Old_Cyl_nr = dl1_Old_Cyl_nr;
                BASE = RL3_base;break;
            }
        }break;
     //---------------------------------------------------------
     case 2: {                                        // from unit 2
        dl2_head = head;                              //
        dl2_Old_head = Old_head;                      ///
        dl2_cnr = Cylinder_nr;                        ////
        dl2_Old_Cyl_nr = Old_Cyl_nr;                  ///// save dl1
        switch(RL_Nr) {
            case 0:                                     //  to Unit 0
                head = dl0_head;
                Old_head = dl0_Old_head;
                Cylinder_nr = dl0_cnr;
                Old_Cyl_nr = dl0_Old_Cyl_nr;
                BASE = RL0_base;break;
            case 1:                                     //  to Unit 1
                head = dl1_head;
                Old_head = dl1_Old_head;
                Cylinder_nr = dl1_cnr;
                Old_Cyl_nr = dl1_Old_Cyl_nr;
                BASE = RL1_base;break;
            case 3:                                     //  to Unit 3
                head = dl3_head;
                Old_head = dl3_Old_head;
                Cylinder_nr = dl3_cnr;
                Old_Cyl_nr = dl3_Old_Cyl_nr;
                BASE = RL3_base;break;
            }
        }break;
    //---------------------------------------------------------
    case 3: {                                        // from unit 3
        dl3_head = head;                             //
        dl3_Old_head = Old_head;                     ///
        dl0_cnr = Cylinder_nr;                       ////
        dl3_Old_Cyl_nr = Old_Cyl_nr;                 ///// save dl1
        switch(RL_Nr) {
            case 0:                                     //  to Unit 0
                head = dl0_head;
                Old_head = dl0_Old_head;
                Cylinder_nr = dl0_cnr;
                Old_Cyl_nr = dl0_Old_Cyl_nr;
                BASE = RL0_base;break;
            case 1:                                     //  to Unit 1
                head = dl1_head;
                Old_head = dl1_Old_head;
                Cylinder_nr = dl1_cnr;
                Old_Cyl_nr = dl1_Old_Cyl_nr;
                BASE = RL1_base;break;
            case 2:                                     //  to Unit 2
                head = dl2_head;
                Old_head = dl2_Old_head;
                Cylinder_nr = dl2_cnr;
                Old_Cyl_nr = dl2_Old_Cyl_nr;
                BASE = RL2_base;break;
            }
        }break;
     //---------------------------------------------------------
    }
    //
    RL_Nr_old = RL_Nr;
    RL_match_old = RL_match;
}
//
//
void sigintHandler(int sig_num)  
{ 
//  Reset handler to catch SIGINT next time. 
    signal(SIGINT, sigintHandler); 
    printf("\n\r rlemulator cannot be terminated using Ctrl+C \n\r"); 
    printf("           Press Button-1 for exit\n\r");
    fflush(stdout); 
} 
//
//
//
//
//                                            §§§§§§§§§§§§§§§§§§§§§§§§§§
//                                            §§§§§§§    MAIN    §§§§§§§
//                                            §§§§§§§§§§§§§§§§§§§§§§§§§§
//
//
int main()
{
  //int i;
  short int errcount=0;
  unsigned int pio;
  strcpy( myfile1, "PDP11GY.INF" );
  format=0;
  //
  init_HW();
  while(priwhile == 0) {    // Primary while
        //
        PRESET_one_SECTOR();                                   // Preset sector
        *(uint32_t *)PIO_0_addr = mode;                        // Clear PIO-0
        *(uint32_t *)PIO_1_addr = mode;                        // Clear PIO-1
        priwhile = 0;
        secwhile = 0;
        //
        printf("\n\r\x1B[2J      *********>  DEC RL01/RL02 EMULATOR  <********** \n\r");
        printf("        SoC/HPS DE10-Nano board based Version V.2.8E             \n\r");
        printf("                   (c) WWW.PDP11GY.COM                           \n\r");
        startup_leds();
        //
        //
        //
        // >>>>>> Check & setup Device Typ, RL01 or RL02<<<<<<<<<<<<
        if (( *(uint32_t *)PIO_1_addr) & 0x0008) {                // SW_5 @ I_ctrl[3]
           RL = 1;                                                // RL02
           rl_status = RL02_OK;
           SDRAM = 11796480;
           MAXCYL = RL02_size;
           strcpy( myfile2, "RL02" );
           printf ("\n\r              >>>>> Device Type = RL02 <<<<");
        } else {
           RL = 0;                                               // RL01
           rl_status = RL01_OK;
           SDRAM = 5898240;
           MAXCYL = RL01_size;
           strcpy( myfile2, "RL01" );
           printf ("\n\r              >>>>> Device Type = RL01 <<<<");
        }
        //
        // >>>>>>>>>>>>>>>>>> Check for debug mode <<<<<<<<<<<<
        if (( *(uint32_t *)PIO_1_addr) & 0x2000) {         // SW_6 @ I_ctrl[13]
           DEBUG = 1;
           printf ("\n\r              >>>>>> DEBUG-MODE = ON <<<<<<");
        } else {
           DEBUG = 0;
           printf ("\n\r              >>>>>> DEBUG-MODE = OFF <<<<<");
        }
        //
        // >>>>>>>>> Check for OFFLINE or ONLINE mode <<<<<<<<<<
        RL_unit = *(uint32_t *)PIO_1_addr >>4  & 0x000F;
        //if (( *(uint32_t *)PIO_1_addr) & 0x1000) {         // SW_6 @ I_ctrl[12]
        if(RL_unit == 0){
           OFFLINE = 1;
           //printf ("\n\r              ******** OFFLINE MODE *******\n\r");
        } else {
           OFFLINE = 0;
           //printf ("\n\r              ******** ONLINE MODE ********\n\r");
        }       
        //
        //  
        //  >>>> get and configure disk-set with all associated file names
        rlname = *(uint32_t *)PIO_1_addr & 0x00F00000;
        switch(rlname){
           case 0x00000000: strcpy( set, "-0.DEC" );strcpy(myfile3,"SN0.TXT");strcpy(myfile4,"RL0.TXT");break;
           case 0x00100000: strcpy( set, "-1.DEC" );strcpy(myfile3,"SN1.TXT");strcpy(myfile4,"RL1.TXT");break;
           case 0x00200000: strcpy( set, "-2.DEC" );strcpy(myfile3,"SN2.TXT");strcpy(myfile4,"RL2.TXT");break;
           case 0x00300000: strcpy( set, "-3.DEC" );strcpy(myfile3,"SN3.TXT");strcpy(myfile4,"RL3.TXT");break;
           case 0x00400000: strcpy( set, "-4.DEC" );strcpy(myfile3,"SN4.TXT");strcpy(myfile4,"RL4.TXT");break;
           case 0x00500000: strcpy( set, "-5.DEC" );strcpy(myfile3,"SN5.TXT");strcpy(myfile4,"RL5.TXT");break;
           case 0x00600000: strcpy( set, "-6.DEC" );strcpy(myfile3,"SN6.TXT");strcpy(myfile4,"RL6.TXT");break;
           case 0x00700000: strcpy( set, "-7.DEC" );strcpy(myfile3,"SN7.TXT");strcpy(myfile4,"RL7.TXT");break;
           case 0x00800000: strcpy( set, "-8.DEC" );strcpy(myfile3,"SN8.TXT");strcpy(myfile4,"RL8.TXT");break;
           case 0x00900000: strcpy( set, "-9.DEC" );strcpy(myfile3,"SN9.TXT");strcpy(myfile4,"RL9.TXT");break;
           case 0x00A00000: strcpy( set, "-A.DEC" );strcpy(myfile3,"SNA.TXT");strcpy(myfile4,"RLA.TXT");break;
           case 0x00B00000: strcpy( set, "-B.DEC" );strcpy(myfile3,"SNB.TXT");strcpy(myfile4,"RLB.TXT");break;
           case 0x00C00000: strcpy( set, "-C.DEC" );strcpy(myfile3,"SNC.TXT");strcpy(myfile4,"RLC.TXT");break;
           case 0x00D00000: strcpy( set, "-D.DEC" );strcpy(myfile3,"SND.TXT");strcpy(myfile4,"RLD.TXT");break;
           case 0x00E00000: strcpy( set, "-E.DEC" );strcpy(myfile3,"SNE.TXT");strcpy(myfile4,"RLE.TXT");break;
           case 0x00F00000: strcpy( set, "-F.DEC" );strcpy(myfile3,"SNF.TXT");strcpy(myfile4,"RLF.TXT");break;
        }
        printf ("\n\r              >>>>>> Disk-subset: %c  <<<<<<",set[1]);
        //
        //
        // >>>> Check and setup available configured units <<<<<
        RL_unit = *(uint32_t *)PIO_1_addr >>4  & ~0xFFF0;
        printf ("\n\r     Configurated RL01/RL02 Unit(s): ");
        if(RL_unit & 0x0001) {
           printf ("DL0: ");
           dl0=1; }        
        if(RL_unit & 0x0002) {
           printf ("DL1: ");
           dl1=1; }
        if(RL_unit & 0x0004) {
           printf ("DL2: ");
           dl2=1; }
        if(RL_unit & 0x0008) {
           printf ("DL3: ");
           dl3=1; }
        //
        //
        if(OFFLINE == TRUE) {
            printf (" no\n\r");
            //printf ("\n\r              ******** OFFLINE MODE *******\n\r");
            make_offline_track0();
               printf ("\n\r         copy  dl0_RAM-area  to  dl1_RAM-area:  ");
               DEST=RL1_base;
               memcpy(&RLDRIVE.rl_drive_i[DEST], &RLDRIVE.rl_drive_i[BASE], SDRAM );
               printf ("\n\r         copy  dl0_RAM-area  to  dl2_RAM-area:  ");
               DEST=RL2_base;
               memcpy(&RLDRIVE.rl_drive_i[DEST], &RLDRIVE.rl_drive_i[BASE], SDRAM ); 
               printf ("\n\r         copy  dl0_RAM-area  to  dl3_RAM-area:  ");
               DEST=RL3_base;
               memcpy(&RLDRIVE.rl_drive_i[DEST], &RLDRIVE.rl_drive_i[BASE], SDRAM );           
        }else{
            //
            printf ("\n\r");
            printf ("\n\r              ******** ONLINE MODE ********\n\r");
            //
            if (~( *(uint32_t *)PIO_1_addr) & 0x0004) {                               // make RL-images on SD card ?
                check_ID();                                                           // NO
                READ_from_SD_Card();
                if (SECTOR.rl02l[127] != 0x45444E45 ) {
                    printf("\n\n\rSD-Card with illegal format detected !");
                    printf("\n\r               Restart system and try again     ");
                    while(1);
                }
            }else {                                                                   // Yes , Make it
                format = 1;                                                           // set Flag 
                printf("\n\r       Inizialize new disk set: %c ",set[1]);
                printf("\n\r       To continue, set SW-0,(=Nr.8) to OFF position.\n\r\n");
                fflush(stdout);
                while (( *(uint32_t *)PIO_1_addr) & 0x0004);
                //usleep( 20*1000 );
                make_myfile_on_SD_Card();
                printf("\n\r");
                printf (" Construct RL01/RL02 cartridge format in RAM \n\r");
                fflush(stdout);
                make_rl_structure_in_ram();
                printf("\n\r*********************************************************");
                usleep( 50*1000 );
                printf ("\r\n     Clone DL0-RAM area to: ");
                printf ("DL1:  ");
                memcpy(&RLDRIVE.rl_drive_i[RL1_base], &RLDRIVE.rl_drive_i[BASE], SDRAM );
                usleep( 50*1000 );
                printf ("DL2:  ");
                memcpy(&RLDRIVE.rl_drive_i[RL2_base], &RLDRIVE.rl_drive_i[BASE], SDRAM );
                usleep( 50*1000 );
                printf ("DL3:  ");
                memcpy(&RLDRIVE.rl_drive_i[RL3_base], &RLDRIVE.rl_drive_i[BASE], SDRAM );
                usleep( 50*1000 );
                //
                SN_default();             // **** Pre-SET Cartridges Serial Numbers ****
                SN_write();               // Write Serial Numbers to SD-Card in file SNx.TXT
                SN_read();                // Read SN's from SD-Card and rebuild data CRC
                //
                printf ("\r\n     Dump RAM to SD-Card into file:");
                PRESET_one_SECTOR();
                WRITE_to_SD_Card(); 
                format=0;               
            }
        }     
        //
        mode = 0x4001;
        *(uint32_t *)PIO_1_addr = mode;                          // Start, Step #1of2 = ENABLE interface
        RL_match = (*(uint32_t *)PIO_1_addr >>8 ) &~0xFFF0;      // get current unit-Nr.
        switch(RL_match) {
            case 0x0001:
                RL_Nr = 0;
                BASE = RL0_base;break;
            case 0x0002:
                RL_Nr = 1;
                BASE = RL1_base;break;
            case 0x0004:
                RL_Nr = 2;
                BASE = RL2_base;break;
            case 0x0008:
                RL_Nr = 3;
                BASE = RL3_base;break;
        }
        //
        SN_read();                       //     Read +  SN's if available + rebuild CRC
        SN_print();                      //     Print SN's
        //
        RL_Nr_old = RL_Nr;               // Preset
        RL_match_old = RL_match;         // Preset
        RAM_Address = BASE;              // Preset
        Old_RAM_Address = RAM_Address;   // Preset
        if(DEBUG == TRUE) {
            printf("\n\r                   selected unit: %d ", RL_Nr );
        }
        //                                                             ##################
        WRITE_drive_to_FPGA(RAM_Address );//                           ### RAM-->FPGA ###
        //                                                             ##################
        errcount=0;
        send_drive_info(rl_status);
        mode=mode|0x00A1;
        *(uint32_t *)PIO_1_addr = mode;
        if(DEBUG == TRUE) {
           printf("\n\r Started with operating mode:  ");
           print_binary_16bit_LSB(mode);printf("    \r\n\n\n");
        }
        //
        //
        //
        //
        //                           §§§§§§§§§§§§§§§§§§§§§§§§§§
        //                           §§§§§§§  MAIN LOOP §§§§§§§
        //                           §§§§§§§§§§§§§§§§§§§§§§§§§§
        //
        //
        //signal(SIGINT, sigintHandler);             // Prevent abort by ctrl-C
        while(secwhile == 0) {                     // Secondary while
        //
        //
        //usleep( 500*1000 );
        //
        // 1)Check if Unit-Number has been changed      AND                            =============1=============
        //   Check if new/changed Unit-Number is also configured
            RL_match = (*(uint32_t *)PIO_1_addr >> 8) &~ 0xFFF0;
            if((RL_match != RL_match_old) & ((RL_unit & RL_match) == RL_match)) {
                *(uint32_t *)PIO_1_addr =  (mode=mode | 0x0010);                    // Set drive to NOT ready @O_ctrl[4]
                RL_drive_nr_changed=TRUE;                                           // indicate 
                //
                //get new Unit-Number
                switch(RL_match) {
                   case 0x0001: RL_Nr = 0; break;
                   case 0x0002: RL_Nr = 1; break;
                   case 0x0004: RL_Nr = 2; break;
                   case 0x0008: RL_Nr = 3; break;
                }
                if(DEBUG == TRUE) {
                    printf("\n\r*********************************************");
                    printf("\n\r****  Current RAM_Address =   %d ", RAM_Address );
                    printf("\n\r****  Switch Unit Number from  %d ", RL_Nr_old );
                    printf(" to %d   **** ", RL_Nr ); 
                }
                READ_drive_from_FPGA(RAM_Address);                                      // Save FPGA/DPR into RAM
                RAM_align();
                RAM_Address = (Cylinder_nr * CYL_size) + head + BASE;                   // Calculate new RAM Address
                WRITE_drive_to_FPGA(RAM_Address);                                       // Write RAM-part to FPGA/DPR
                if(DEBUG == TRUE) {
                    printf("\n\r****  New RAM address : %d", RAM_Address);
                    printf("\n\r*********************************************");
                    fflush(stdout);
                }
            }
            *(uint32_t *)PIO_1_addr = (mode=mode &~ 0x0010);                       // ReSet drive to  ready @O_ctrl[4]
            //
            //
            // 2) check for drive command @ I_ctrl[1]                               =============2=============
            //
            //if (( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE) & 0x0002)) {            // test @ I_ctrl[1]
            if ( *(uint32_t *)PIO_1_addr & 0x0002 ) {                               // test @ I_ctrl[1]
                if(RL_drive_nr_changed==FALSE) {                                    // -----No UNIT Change-----
                    //
                    //
                    //pio = IORD_ALTERA_AVALON_PIO_DATA(PIO_0_BASE);                 // get command > pio
                    pio = *(uint32_t *)PIO_0_addr;                                   // get command > pio
                    if(DEBUG == TRUE){
                        printf("\n\rDrive command received: ");
                        print_binary_16bit_LSB(pio); fflush(stdout);
                    }
                    if(RL == 0) {
                        pio = pio &~0x8000;                                          // RL01 !!
                        if(DEBUG == TRUE){
                            printf("\n\r  Drive command modified: ");
                            print_binary_16bit_LSB(pio); fflush(stdout);
                        }
                    }
                    //
                    Cylinder_nr_diff = (pio >>7);                                  // get Cylinder Address-Difference
                    //
                    if(pio & 0x0010){                                              // get head number & define offset
                        head = DPR_size; } else { head = 0;                         // Bit 04 = Head select
                    }
                    if(DEBUG == TRUE) {
                        printf("\n\r  Cylinder difference : %d ", Cylinder_nr_diff ); 
                        }
                    if(head == 0){
                        rl_status = (rl_status &~ 0x0040);                         // Indicate: head 0 in use
                    } else {
                        rl_status = (rl_status |  0x0040);                         // indicate: head 1 in use
                    }
                    send_drive_info(rl_status);					
					//printf("."); 
					fflush(stdout);
                    //      
                    if((Cylinder_nr_diff == 0) & (head == Old_head)) {
                        acknowledge();                                             // all done
                        if(DEBUG == TRUE)
                            {
                            printf("\n\r     Request with no action    ");
                        }
                    } else {
                        if(DEBUG == TRUE){
                            if((head != Old_head) & (head == DPR_size)) {
                                    printf("    Using head 1   ");
                                }else{
                                    printf("    Using head 0   ");
                            }
                        }
                    }
                    fflush(stdout);
                    //                                                           // ##################
                    READ_drive_from_FPGA(Old_RAM_Address);                       // ### FPGA-->RAM ###
                    //                                                           // ##################
                    //
                    if(pio & 0x0004){
                        // 1= move heads toward spindle
                        Cylinder_nr = (Cylinder_nr + Cylinder_nr_diff);
						if(Cylinder_nr > MAXCYL) {                                         // Error check
							printf("\n\r\n	Seek error to cylinder: %d ", Cylinder_nr );
							printf("\n\r	exceeds the maximum of cylinder: %d ", MAXCYL );
							Cylinder_nr = (Cylinder_nr - Cylinder_nr_diff);
							printf("\n\r	Recover to cylinder: %d \r\n", Cylinder_nr );
						    fflush(stdout);
						}
                    } else {
                        // 0= move heads away from spindle
                        Cylinder_nr = (Cylinder_nr - Cylinder_nr_diff);	
						//if(Cylinder_nr < 0) {
                    }
                    //
                    //
                    if(Cylinder_nr < 0) {
                        errcount++;
                        if(errcount > 10){
                            printf("\n\n\n\r >>>           Fatal Error        <<<<");
                            printf("\n\r >>> New physical cylinder is negativ  %d ", Cylinder_nr );
                            printf("\n\r >>>           System halt         <<<");
							fflush(stdout);
                            exit(0);
                        }else{
                            printf("\n\r >>>              Error         <<<");
                            printf("\n\r >>> New physical cylinder is negativ  %d ", Cylinder_nr );
                            printf("\n\r >>>             Recover         <<<");
                            Cylinder_nr = 0;
                            RAM_Address = BASE;
                        }
                    }else{
                        //
                        // Calculate index for RAM/union
                        RAM_cyl_addr = (Cylinder_nr * CYL_size);
                        if(DEBUG == TRUE) {                         
                            printf("\n\r  to: Cylinder-Nr. %d = RAM-address: %d ",
                                    Cylinder_nr, RAM_cyl_addr+head );
                            fflush(stdout);
                        }
                        RAM_Address = BASE + RAM_cyl_addr + head;                // Calculate new RAM address
                        // restart cycle = read selected track from RAM into FPGA/DPR
                    }
                    //
                    //                                                          // ##################
                    WRITE_drive_to_FPGA(RAM_Address);                           // ### RAM-->FPGA ###
                    //                                                          // ##################
                    //
                    Old_head  = head;                                           // Save
                    Old_Cyl_nr = Cylinder_nr;                                   // Save
                    Old_RAM_Address = RAM_Address;                              // Save
                    //
                    acknowledge();                                              // All done ...indicate
                    //
                    //
                }else{                                                          //  ----- UNIT Change-----
                    Old_RAM_Address = RAM_Address;                              // Save RAM-Address
                    if(head == 0){
                        rl_status = (rl_status &~ 0x0040);                        // Indicate: head 0 in use
                    } else {
                        rl_status = (rl_status |  0x0040);                        // indicate: head 1 in use
                    }
                    rl_status = (rl_status |  0x0200);                          // set Volume-Check
                    send_drive_info(rl_status);
					acknowledge();
                    rl_status = (rl_status &~ 0x0200);                          // clear Volume-Check
                    RL_drive_nr_changed=FALSE;                                  // Unit-Change done.
                }
            }
            //
            //      
            //
            // 3) check for RECONFIG request.                                 =============3=============
            if ( ~ *(uint32_t *)PIO_1_addr & 0x4000 ) {         //  Button_2  @ I_ctrl[14]   ? 
                usleep( 500*1000 );
                //while(*(uint32_t *)PIO_1_addr & 0x4000)
                RL_unit = (*(uint32_t *)PIO_1_addr >>4)  &~0xFFF0;
                printf ("\n\r\n Reconfigurated RL01/RL02 Unit(s): ");
                if(RL_unit & 0x0001) {
                   printf ("DL0: ");
                   dl0=1;
                }
                if(RL_unit & 0x0002) {
                    printf ("DL1: ");
                    dl1=1;
                }
                if(RL_unit & 0x0004) {
                    printf ("DL2: ");
                    dl2=1;
                }
                if(RL_unit & 0x0008) {
                    printf ("DL3: ");
                    dl3=1;
                }
            printf ("\n\n\r");
            }
            //
            //
            // 4) check for power fail or reset                              =============4=============
            if (( ~ *(uint32_t *)PIO_1_addr & 0x8000 ) | ( ~ *(uint32_t *)PIO_1_addr & 0x0001 )) {
                if( OFFLINE == FALSE ) {   
                    printf("    Key[1] / Power-fail   \n\r");
                    usleep( 500*1000 );
                    printf("\x1B[2J\n\r\x07        ......... Shutting down system .........\n\r");
                    READ_drive_from_FPGA(Old_RAM_Address);
                    Old_Cyl_nr = 0;
                    //....save
                    WRITE_to_SD_Card();                    
                    *(uint32_t *)PIO_0_addr = 0x0000;                        // Clear PIO-0
                    *(uint32_t *)PIO_1_addr = 0x000C;                        // Clear PIO-1
                } else {
                    *(uint32_t *)PIO_0_addr = 0x0000;                        // Clear PIO-0
                    *(uint32_t *)PIO_1_addr = 0x000C;                        // Clear PIO-1
                    printf("\x07\n\n\r        *** System switched down *** \n\r"); 
                }
                secwhile = 1;               
            }                       
        } // Secondary while
        while ( ~ *(uint32_t *)PIO_1_addr & 0x8000 );   // Reset/Exit,       = Button 1 released
        usleep( 500*1000 );
        while ( ~ *(uint32_t *)PIO_1_addr & 0x4000 );   // Reconfig/Restart, = Button 2 released
        usleep( 500*1000 );
        printf("\x07\n\n\r  Press RESET/Button-1 for exit, Reconfig/Button-2 for restart  \n\r");
        priwhile = 2;
        while(priwhile == 2) {
            if ( ~ *(uint32_t *)PIO_1_addr & 0x4000 ) {  // Reconfig/Restart
                usleep( 500*1000 );
                secwhile = 0;
                priwhile = 0;
            }
            if ( ~ *(uint32_t *)PIO_1_addr & 0x8000 ) {  // Reset/EXit
                printf("\x07\n\n\r    Servus & Bye\n\r\n");
                fflush(stdout);
                usleep( 500*1000 );
                secwhile = 1;
                priwhile = 1;
            }
        }
    } // Primary while
    return 0; 
}
