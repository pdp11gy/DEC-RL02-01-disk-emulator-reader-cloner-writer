
If you want to build everything into a box, access to the slide switches 
will also be difficult. Now it is possible to control alternatively the 
function of the slide switches.
With the DE10-Nano board version, the micro SD card on the interface is not 
required. So, there are 4 pins left as you can see in the attached picture. 
These 4 pins plus ground can be used for external connected slide switches.

FPGA/AE19=PIN39 -> ex_0   XOR  OB_SW_0
FPGA/AE17=PIN40 -> ex_1   XOR  OB_SW_1
FPGA/AG15=PIN37 -> ex_2   XOR  OB_SW_2
FPGA/AE20=PIN38 -> ex_3   XOR  OB_SW_3  

To Do: 
Replace the firmware file RL_EMULATOR_SoC.rbf with the file in this folder
or create another link:
ln -s ./INFOs/extern_switches/RL_EMULATOR_SoC.rbf fpga_config_file.rbf 