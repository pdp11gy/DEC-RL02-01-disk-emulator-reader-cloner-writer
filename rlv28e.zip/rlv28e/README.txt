Overview and content:

_socv_2_3 	= Folder, previous version : RL Emulator 	Version V2.3
_clonerl_2_5 	= Folder, previous version : RL Reader/Cloner	Version V2.5 
flash		= Folder, firmware flash files
INFOs		= Folder, Additional HW Information, see README.txt




		************************************************
		* Please read pdf-Version : RL-disk-emuclo.pdf *
		************************************************

Get started , RL01/RL02 emulator/cloner/reader
-----------------------------------------------

Reference:
RL01/RL02 emulator manual:     RL-disk-emuclo.pdf
https://github.com/pdp11gy/DEC-RL02-01-disk-emulator-reader-cloner-writer

Before you start:
In order to start the clonrl program, a HW change(FCO) must be made on the interface 
board. Background:
Generally: Only(!) the 40pin flat-cable has to be plugged into the RL interface 
board by 180 degrees, i.e. reversed. However, there is one exception, the Power-OK 
signal. This signal is present at PIN A as input in slave mode and as output at 
pin VV in master mode. However, pin VV is connected to ground on the interface board.
Todo: 
Cut the ground etch to pin VV and connected the pin to +5 VCC via a resistor
about 300 Ohm. More detail in user manual RL-disk-emuclo.pdf

	FPGA+PINs    	    Emulator-Mode                   Clone-Mode
                    |
	AG25=13	  B/A=	 01  Power_ok	 -|+		39  --------------
	AH26=14	  D/C=	 03  Drive-sel_0 -|+		37  Drive-Error +|-
	AH24=15	  F/E=	 05  Drive-sel_1 -|+		35  Drive-ready +|-
	AF25=16	  J/H=	 07  Write-gate  -|+		33  Sector	+|-
	--	  L/K=	 09  ---------------		31  ---------------
	AG23=17	  N/M=	 11  System-Clk  -|+		29  Status-Clk	+|-  
	--	  R/P=	 13  ---------------		27  ---------------
	AF23=18	  T/S=	 15  Write-data  -|+            25  Status-IN 	+|-
	--	  V/U=	 17  ---------------		23  ---------------
	AG24=19	  X/W=	 19  Command  	 -|+		21  Read-data   +|-
	===================================================================
	AH22=20	  Z/Y=	 21  Read-data   -|+		19  Command  	+|-
	--	 BB/AA=	 23  ---------------		17  ---------------
	AH21=21	 DD/CC=	 25  Status-IN 	 -|+		15  Write-data  +|- 
	--	 FF/EE=	 27  ---------------		13  ---------------
	AF22=25	 JJ/HH=	 29  Status-Clk	 -|+		11  System-Clk  +|-
	--	 LL/KK=	 31  ---------------		09  --------------- 
	AG20=27	 NN/MM=	 33  Sector	 -|+		07  Write-gate  +|-
	AH19=32	 RR/PP=	 35  Drive-ready -|+		05  Drive-sel_1 +|-
	AH18=34	 TT/SS=	 37  Drive-Error -|+		03  Drive-sel_0	+|-
	--	 VV/UU=	 39  ---------------  		01  Power_ok	+|-
                 |

Folders:

flash:	Contains the RL_EMULATOR_SoC.jic file for flashing the FW into the EPCS and
	the RL_EMULATOR_SoC.rbf for loading the FW in the FPGA.
	The .cof file are configuration files if you want to convert the .sof file
	to .jic or .rbf by yourself. 

Programs:  clonerl , rlemulator , loadrbf and  pdp11(from SIMH project).

Installation: 
-  copy the rlv28e.zip file to the target and unzip the file there.
-	cd rlv28e
-	ln -s ./flash/RL_EMULATOR_SoC.rbf fpga_config_file.rbf
-	./loadrbf
-> start the program ./clonerl or ./rlemulator or ./pdp11


Changes to the previous versions:
In the new version V2.8, mainly in the clonerl program, FW changes were made to 
the PLL and MFM decoders. In addition, extensive error handling was implemented 
in the C program. If there are problems with version V2.8, I ask you to test 
the previous versions as well. These versions are located in the _socv_2_3 
and _clonerl_2_5 folders. In the corresponding readme file you will find all 
further information to install the previous versions. All sources are located
at GitHub : https://github.com/pdp11gy/SoC-HPS-based-RL-disk-emulator

 

                        ------------------------------
                                 www.pdp11gy.com
                             E-Mail: info@pdp11gy.com
                       -------------------------------

